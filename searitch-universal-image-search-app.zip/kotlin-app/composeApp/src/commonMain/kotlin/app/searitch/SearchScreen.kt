@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package app.searitch

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.lazy.staggeredgrid.itemsIndexed
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.lazy.staggeredgrid.rememberLazyStaggeredGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/* ───────────────────────── smart facets & active filters ─────────────────── */

private data class Facet(val label: String, val count: Int, val next: Filters)

/** Drill-down suggestions computed from the images actually returned, with real counts. */
private fun buildFacets(results: List<SearitchImage>, f: Filters): List<Facet> {
    if (results.size < 6) return emptyList()
    val out = mutableListOf<Facet>()
    val typed = listOf(TypeFilter.JPG, TypeFilter.PNG, TypeFilter.GIF, TypeFilter.SVG)
    results.groupingBy { it.filetype.lowercase() }.eachCount().entries
        .sortedByDescending { it.value }.take(3).forEach { (ext, n) ->
            val t = typed.firstOrNull { it.name.lowercase() == ext }
            if (t != null && n >= 3 && f.type != t) out += Facet("${t.label} only", n, f.copy(type = t))
        }
    val siteMap = mapOf(
        "flickr" to ProviderFilter.FLICKR,
        "wallhaven" to ProviderFilter.WALLHAVEN,
        "wikimedia commons" to ProviderFilter.WIKIMEDIA,
        "inaturalist" to ProviderFilter.INATURALIST,
        "nasa" to ProviderFilter.NASA,
        "the met" to ProviderFilter.MET,
        "v&a museum" to ProviderFilter.VAM,
    )
    results.groupingBy { it.sourceSite }.eachCount().entries
        .sortedByDescending { it.value }.take(3).forEach { (site, n) ->
            val p = siteMap[site.lowercase()]
            if (p != null && n >= 3 && f.provider != p) out += Facet(site, n, f.copy(provider = p))
        }
    val wide = results.count { it.width > 0 && it.height > 0 && it.width.toFloat() / it.height >= 1.2f }
    val tall = results.count { it.width > 0 && it.height > 0 && it.width.toFloat() / it.height <= 1f / 1.2f }
    if (wide >= 4 && f.aspect != AspectFilter.WIDE) out += Facet("Landscape", wide, f.copy(aspect = AspectFilter.WIDE))
    if (tall >= 4 && f.aspect != AspectFilter.TALL) out += Facet("Portrait", tall, f.copy(aspect = AspectFilter.TALL))
    val big = results.count { it.width.toLong() * it.height >= 6_000_000L }
    if (big >= 4 && f.size != SizeFilter.LARGE) out += Facet("High-res", big, f.copy(size = SizeFilter.LARGE))
    return out.take(6)
}

private fun activeLabels(f: Filters): List<Pair<String, Filters>> = buildList {
    if (f.type != TypeFilter.ANY) add(f.type.label to f.copy(type = TypeFilter.ANY))
    if (f.aspect != AspectFilter.ANY) add(f.aspect.label to f.copy(aspect = AspectFilter.ANY))
    if (f.size != SizeFilter.ANY) add("${f.size.label} size" to f.copy(size = SizeFilter.ANY))
    COLOR_OPTIONS.firstOrNull { it.key == f.color }?.let { add(it.label to f.copy(color = "")) }
    if (f.license != LicenseFilter.ANY) add(f.license.label to f.copy(license = LicenseFilter.ANY))
    if (f.provider != ProviderFilter.ALL) add(f.provider.label to f.copy(provider = ProviderFilter.ALL))
    if (!f.safe) add("Safe search: OFF" to f.copy(safe = true))
    if (!f.antiAi) add("AI Art: Allowed" to f.copy(antiAi = true))
}

private fun merge(current: List<SearitchImage>, chunk: List<SearitchImage>): List<SearitchImage> {
    val seenFull = current.mapTo(HashSet()) { it.full }
    val seenId = current.mapTo(HashSet()) { it.id }
    return current + chunk.filter { seenFull.add(it.full) && seenId.add(it.id) }
}

private val SKELETON_RATIOS = listOf(1.5f, 0.75f, 1.1f, 0.7f, 1.35f, 0.9f, 1.6f, 0.8f)

/* ───────────────────────────────── screen ────────────────────────────────── */

@Composable
fun SearchScreen(
    initialQuery: String,
    onOpenImage: (SearitchImage) -> Unit,
    onBack: () -> Unit,
) {
    var query by remember { mutableStateOf(initialQuery) }
    var input by remember { mutableStateOf(initialQuery) }
    var filters by remember { mutableStateOf(Filters()) }
    var draft by remember { mutableStateOf(Filters()) }
    var results by remember { mutableStateOf<List<SearitchImage>>(emptyList()) }
    var pages by remember { mutableIntStateOf(1) }
    var lastCount by remember { mutableIntStateOf(0) }
    var done by remember { mutableStateOf(false) }
    var loadingMore by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var retryTick by remember { mutableIntStateOf(0) }
    var sheetOpen by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    val gridState = rememberLazyStaggeredGridState()
    val navPad = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    // Page 1 streams in per source: the first photos appear after the fastest one.
    LaunchedEffect(query, filters, retryTick) {
        results = emptyList(); pages = 1; lastCount = 0; done = false; error = null
        var failure: Throwable? = null
        try {
            Api.searchStream(query, filters, 1).collect { chunk -> results = merge(results, chunk) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            failure = e
        }
        lastCount = results.size
        done = true
        if (results.isEmpty()) error = failure?.message
    }

    val hasMore = done && lastCount >= 12 && pages < 20
    val loadMore: () -> Unit = {
        if (hasMore && !loadingMore) {
            loadingMore = true
            val next = pages + 1
            scope.launch {
                var added = 0
                try {
                    Api.searchStream(query, filters, next).collect { chunk ->
                        val before = results.size
                        results = merge(results, chunk)
                        added += results.size - before
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Throwable) {
                }
                pages = next
                lastCount = added
                loadingMore = false
            }
        }
    }
    val loadMoreNow by rememberUpdatedState(loadMore)
    val sizeNow by rememberUpdatedState(results.size)

    // Endless scroll: fetch the next page well before the user reaches the end.
    LaunchedEffect(gridState) {
        snapshotFlow { gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
            .collect { last -> if (last >= sizeNow - 6) loadMoreNow() }
    }

    val facets = remember(results, filters) { buildFacets(results, filters) }
    val active = remember(filters) { activeLabels(filters) }
    val loading = results.isEmpty() && !done

    val showTop by remember {
        derivedStateOf {
            gridState.firstVisibleItemIndex > 1 || gridState.firstVisibleItemScrollOffset > 480
        }
    }

    Box(Modifier.fillMaxSize().leatherSurface(tall = true)) {
    Column(Modifier.fillMaxSize()) {
        /* ── leather strap ── */
        Box(Modifier.zIndex(1f)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(8.dp)
                    .leatherStrap()
                    .statusBarsPadding()
                    .padding(start = 10.dp, end = 10.dp, top = 10.dp, bottom = 17.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                WellButton(onClick = onBack) { Icon(Ico.Back, Ink.thread, Modifier.size(24.dp)) }
                Row(
                    modifier = Modifier
                        .sharedField()
                        .weight(1f)
                        .height(44.dp)
                        .paperField()
                        .padding(start = 12.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    BasicTextField(
                        value = input,
                        onValueChange = { input = it },
                        singleLine = true,
                        textStyle = TextStyle(color = Ink.strong, fontSize = 15.sp, fontWeight = FontWeight.SemiBold),
                        cursorBrush = SolidColor(Brass.dark),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = {
                            input.trim().takeIf { it.isNotEmpty() }?.let { query = it }
                        }),
                        decorationBox = { inner ->
                            Box(contentAlignment = Alignment.CenterStart) {
                                if (input.isEmpty()) {
                                    Text("Search images…", color = Ink.faint, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                }
                                inner()
                            }
                        },
                        modifier = Modifier.weight(1f).padding(end = 4.dp),
                    )
                    if (input.isNotEmpty()) {
                        Box(
                            Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                ) { input = "" },
                            contentAlignment = Alignment.Center,
                        ) { Icon(Ico.Close, Ink.faint, Modifier.size(16.dp)) }
                    }
                    // Filter lives IN the field so it can never be pushed off a portrait screen.
                    Box(
                        Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                            ) { draft = filters; sheetOpen = true },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Ico.Filter, Color(0xFF4A3B28), Modifier.size(20.dp))
                        if (filters.activeCount > 0) {
                            Box(
                                Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .size(14.dp)
                                    .background(Color(0xFFB03A26), CircleShape),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    "${filters.activeCount}",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                )
                            }
                        }
                    }
                }
            }
            if (!done) ProgressThread(Modifier.align(Alignment.BottomCenter))
        }

        /* ── results ── */
        LazyVerticalStaggeredGrid(
            columns = StaggeredGridCells.Adaptive(minSize = 150.dp),
            state = gridState,
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 96.dp + navPad),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalItemSpacing = 10.dp,
            modifier = Modifier.fillMaxSize(),
        ) {
            if (active.isNotEmpty() || facets.isNotEmpty()) {
                item(span = StaggeredGridItemSpan.FullLine, key = "chips") {
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        active.forEach { (label, without) -> SearitchChip("$label ×", true) { filters = without } }
                        facets.forEach { fc -> SearitchChip("${fc.label}  ${fc.count}", false) { filters = fc.next } }
                    }
                }
            }
            when {
                loading -> items(8) { i -> SkeletonCard(SKELETON_RATIOS[i % SKELETON_RATIOS.size], i) }

                results.isEmpty() -> item(span = StaggeredGridItemSpan.FullLine, key = "empty") {
                    EmptyState(
                        message = error ?: "No images matched. Try a broader keyword or loosen a filter.",
                        isError = error != null,
                        active = active,
                        onRemove = { filters = it },
                        onClear = { filters = Filters() },
                        onRetry = { retryTick++ },
                    )
                }

                else -> {
                    item(span = StaggeredGridItemSpan.FullLine, key = "count") {
                        Text(
                            "${results.size}${if (hasMore || !done) "+" else ""} RESULTS · “${query.uppercase()}”",
                            style = TextStyle(
                                color = Ink.onLeather,
                                fontFamily = cinzel(),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                letterSpacing = 2.sp,
                            ),
                            modifier = Modifier.padding(start = 2.dp, top = 2.dp),
                        )
                    }
                    itemsIndexed(results, key = { _, img -> img.id }) { index, img ->
                        PhotoCard(img, index) { onOpenImage(it) }
                    }
                    if (loadingMore) {
                        item(span = StaggeredGridItemSpan.FullLine, key = "more") {
                            Box(Modifier.fillMaxWidth().padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(
                                    color = Brass.base,
                                    trackColor = Leather.light,
                                    modifier = Modifier.size(26.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    /* ── filter sheet ── */
    if (sheetOpen) {
        ModalBottomSheet(
            onDismissRequest = { sheetOpen = false },
            sheetState = sheetState,
            containerColor = Leather.base,
            dragHandle = {
                Box(
                    Modifier
                        .padding(vertical = 10.dp)
                        .size(width = 44.dp, height = 5.dp)
                        .clip(CircleShape)
                        .background(Ink.thread.copy(alpha = 0.5f)),
                )
            },
        ) {
            Column(
                Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp)
                    .padding(bottom = 28.dp),
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "FILTERS",
                        style = TextStyle(
                            color = Ink.onLeather,
                            fontFamily = cinzel(),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            letterSpacing = 3.sp,
                        ),
                    )
                    SearitchChip("Reset all", selected = false) { draft = Filters() }
                }

                Column(
                    Modifier.fillMaxWidth().paperSurface(RoundedCornerShape(8.dp)).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    FilterSection("FILE TYPE", TypeFilter.entries, draft.type, { it.label }) { draft = draft.copy(type = it) }
                    FilterSection("ORIENTATION", AspectFilter.entries, draft.aspect, { it.label }) { draft = draft.copy(aspect = it) }
                    FilterSection("SIZE", SizeFilter.entries, draft.size, { it.label }) { draft = draft.copy(size = it) }
                    Column {
                        SectionLabel("COLOR")
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(9.dp),
                            verticalArrangement = Arrangement.spacedBy(9.dp),
                        ) {
                            COLOR_OPTIONS.forEach { c ->
                                val selected = draft.color == c.key
                                Box(
                                    Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(Color(c.hex))
                                        .border(
                                            if (selected) 3.dp else 1.dp,
                                            if (selected) Brass.base else Color.Black.copy(alpha = 0.25f),
                                            CircleShape,
                                        )
                                        .clickable { draft = draft.copy(color = if (selected) "" else c.key) },
                                )
                            }
                        }
                    }
                    FilterSection("LICENSE", LicenseFilter.entries, draft.license, { it.label }) { draft = draft.copy(license = it) }
                    FilterSection("SOURCE", ProviderFilter.entries, draft.provider, { it.label }) { draft = draft.copy(provider = it) }

                    Column {
                        SectionLabel("SAFE SEARCH")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SearitchChip("Strict (Safe ON)", draft.safe) { draft = draft.copy(safe = true) }
                            SearitchChip("Off (Unrestricted)", !draft.safe) { draft = draft.copy(safe = false) }
                        }
                        Text(
                            "Hides adult or explicit content identified by the source. Some sources provide limited safety metadata.",
                            color = Ink.faint,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(top = 5.dp),
                        )
                    }

                    Column {
                        SectionLabel("ANTI-AI FILTER")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SearitchChip("Block AI Images (ON)", draft.antiAi) { draft = draft.copy(antiAi = true) }
                            SearitchChip("Allow AI Art", !draft.antiAi) { draft = draft.copy(antiAi = false) }
                        }
                        Text(
                            "Hides results whose title, tags or creator identify AI generation. Unlabelled AI images may still appear.",
                            color = Ink.faint,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(top = 5.dp),
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))
                BrassButton("Apply filters", Modifier.fillMaxWidth()) {
                    filters = draft
                    scope.launch { sheetState.hide() }.invokeOnCompletion { sheetOpen = false }
                }
            }
        }
    }
    if (showTop) {
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = navPad + 20.dp)
                .size(48.dp)
                .shadow(6.dp, CircleShape)
                .clip(CircleShape)
                .background(brassBrush())
                .border(1.dp, Brass.dark, CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                ) { scope.launch { gridState.animateScrollToItem(0) } },
            contentAlignment = Alignment.Center,
        ) { Icon(Ico.Up, Brass.text, Modifier.size(22.dp)) }
    }
    }
}

/* ─────────────────────────────── pieces ──────────────────────────────────── */

/** A thread of light running under the strap while a search is still arriving. */
@Composable
private fun ProgressThread(modifier: Modifier) {
    val transition = rememberInfiniteTransition(label = "thread")
    val x by transition.animateFloat(
        initialValue = -0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1050, easing = FastOutSlowInEasing)),
        label = "threadX",
    )
    Box(
        modifier
            .fillMaxWidth()
            .height(2.dp)
            .drawBehind {
                val w = size.width * 0.38f
                val left = size.width * x
                drawRect(
                    brush = Brush.horizontalGradient(
                        listOf(Color.Transparent, Color(0xFFF1D98F), Color.Transparent),
                        startX = left,
                        endX = left + w,
                    ),
                    topLeft = Offset(left, 0f),
                    size = Size(w, size.height),
                )
            },
    )
}

@Composable
private fun EmptyState(
    message: String,
    isError: Boolean,
    active: List<Pair<String, Filters>>,
    onRemove: (Filters) -> Unit,
    onClear: () -> Unit,
    onRetry: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 24.dp)
            .paperSurface(RoundedCornerShape(8.dp))
            .padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Ico.Search, Ink.faint, Modifier.size(28.dp))
        Text(
            if (isError) "Couldn’t search" else "Nothing found",
            style = TextStyle(color = Ink.danger, fontFamily = cinzel(), fontWeight = FontWeight.Bold, fontSize = 18.sp),
            modifier = Modifier.padding(top = 10.dp),
        )
        Text(message, color = Ink.soft, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, bottom = 14.dp))
        if (active.isNotEmpty()) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                active.forEach { (label, without) -> SearitchChip("Remove $label", false) { onRemove(without) } }
                if (active.size > 1) SearitchChip("Clear all filters", true) { onClear() }
            }
        }
        if (isError || active.isEmpty()) {
            Spacer(Modifier.height(12.dp))
            BrassButton("Try again", Modifier.width(180.dp)) { onRetry() }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        style = TextStyle(
            color = Ink.faint,
            fontFamily = cinzel(),
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            letterSpacing = 2.sp,
        ),
        modifier = Modifier.padding(bottom = 8.dp),
    )
}

@Composable
private fun <T> FilterSection(
    label: String,
    options: List<T>,
    selected: T,
    text: (T) -> String,
    onSelect: (T) -> Unit,
) {
    Column {
        SectionLabel(label)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            options.forEach { opt -> SearitchChip(text(opt), selected = opt == selected) { onSelect(opt) } }
        }
    }
}
