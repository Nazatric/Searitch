@file:OptIn(ExperimentalSharedTransitionApi::class)

package app.searitch

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.IntOffset
import coil3.ImageLoader
import coil3.compose.setSingletonImageLoaderFactory
import coil3.network.ktor3.KtorNetworkFetcherFactory

/** Simple, dependency-free navigation back-stack. */
sealed interface Screen {
    data object Home : Screen
    data class Search(val query: String) : Screen
    data class Detail(val image: SearitchImage) : Screen
}

@Composable
fun App() {
    setSingletonImageLoaderFactory { context ->
        ImageLoader.Builder(context)
            .components { add(KtorNetworkFetcherFactory()) }
            .build()
    }

    val backStack = remember { mutableStateListOf<Screen>(Screen.Home) }
    fun push(s: Screen) {
        backStack.add(s)
    }
    fun pop() {
        if (backStack.size > 1) backStack.removeAt(backStack.lastIndex)
    }

    // Android back button / gesture pops the stack instead of closing the app.
    PlatformBackHandler(enabled = backStack.size > 1) { pop() }

    SearitchTheme {
        Surface(Modifier.fillMaxSize(), color = Leather.dark) {
            // Photos and the search field fly between screens (shared elements).
            SharedTransitionLayout {
                AnimatedContent(
                    targetState = backStack.last(),
                    contentKey = { s ->
                        when (s) {
                            is Screen.Home -> "home"
                            is Screen.Search -> "search"
                            is Screen.Detail -> "detail:${s.image.id}"
                        }
                    },
                    transitionSpec = {
                        val photoFlight = targetState is Screen.Detail || initialState is Screen.Detail
                        if (photoFlight) {
                            // keep the cross-fade short: the shared photo does the moving
                            fadeIn(tween(200)) togetherWith fadeOut(tween(200))
                        } else {
                            val pushing = targetState is Screen.Search
                            val spec = spring<IntOffset>(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow)
                            if (pushing) {
                                (slideInHorizontally(spec) { it / 4 } + fadeIn(tween(220)))
                                    .togetherWith(slideOutHorizontally(spec) { -it / 5 } + fadeOut(tween(180)))
                            } else {
                                (slideInHorizontally(spec) { -it / 5 } + fadeIn(tween(220)))
                                    .togetherWith(slideOutHorizontally(spec) { it / 4 } + fadeOut(tween(180)))
                            }
                        }
                    },
                    label = "screens",
                ) { screen ->
                    CompositionLocalProvider(
                        LocalSharedScope provides this@SharedTransitionLayout,
                        LocalVisibilityScope provides this@AnimatedContent,
                    ) {
                        when (screen) {
                            is Screen.Home -> HomeScreen(onSearch = { push(Screen.Search(it)) })
                            is Screen.Search -> SearchScreen(
                                initialQuery = screen.query,
                                onOpenImage = { push(Screen.Detail(it)) },
                                onBack = ::pop,
                            )
                            is Screen.Detail -> DetailScreen(
                                img = screen.image,
                                onOpenImage = { push(Screen.Detail(it)) },
                                onBack = ::pop,
                            )
                        }
                    }
                }
            }
        }
    }
}
