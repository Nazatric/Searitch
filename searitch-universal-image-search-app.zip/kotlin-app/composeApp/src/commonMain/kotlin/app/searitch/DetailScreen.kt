@file:OptIn(ExperimentalLayoutApi::class)

package app.searitch

import androidx.compose.foundation.Image as ComposeImage
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.lazy.staggeredgrid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import coil3.Image as CoilImage
import coil3.compose.AsyncImage
import coil3.compose.AsyncImagePainter
import coil3.compose.rememberAsyncImagePainter

/** A sharper-than-thumbnail rendition for the hero (Wikimedia serves any standard width). */
private fun heroModel(img: SearitchImage): String =
    if (img.width >= 1280 && Regex("/thumb/.+/\\d+px-").containsMatchIn(img.thumb)) {
        img.thumb.replace(Regex("/\\d+px-"), "/1280px-")
    } else {
        img.full
    }

private val SKELETON_RATIOS = listOf(1.5f, 0.75f, 1.1f, 0.7f, 1.35f, 0.9f)

@Composable
fun DetailScreen(img: SearitchImage, onOpenImage: (SearitchImage) -> Unit, onBack: () -> Unit) {
    var related by remember(img.id) { mutableStateOf<List<SearitchImage>?>(null) }
    val uriHandler = LocalUriHandler.current
    val navPad = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    LaunchedEffect(img.id) {
        related = runCatching { Api.related(img) }
            .getOrDefault(emptyList())
            .filter { it.id != img.id }
            .take(18)
    }

    val ratio = if (img.width > 0 && img.height > 0) {
        (img.width.toFloat() / img.height).coerceIn(0.5f, 2.2f)
    } else {
        4f / 3f
    }
    val heroPainter = rememberAsyncImagePainter(model = heroModel(img))
    val decodedHero: CoilImage? =
        (heroPainter.state as? AsyncImagePainter.State.Success)?.result?.image
    // On Android 14+, the window switches to HDR only when this decoded image
    // actually contains an Ultra HDR gain map. SDR sources remain ordinary SDR.
    PlatformHdrWindow(image = decodedHero, enabled = true)

    Column(Modifier.fillMaxSize().leatherSurface(tall = true)) {
        /* ── leather strap ── */
        Row(
            modifier = Modifier
                .zIndex(1f)
                .fillMaxWidth()
                .shadow(8.dp)
                .leatherStrap()
                .statusBarsPadding()
                .padding(start = 10.dp, end = 10.dp, top = 10.dp, bottom = 17.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            WellButton(onClick = onBack) { Icon(Ico.Back, Ink.thread, Modifier.size(24.dp)) }
            Text(
                img.title,
                style = TextStyle(
                    color = Ink.onLeather,
                    fontFamily = cinzel(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    letterSpacing = 0.6.sp,
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
        }

        LazyVerticalStaggeredGrid(
            columns = StaggeredGridCells.Adaptive(minSize = 150.dp),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 16.dp, bottom = 32.dp + navPad),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalItemSpacing = 10.dp,
            modifier = Modifier.fillMaxSize(),
        ) {
            /* ── the mounted photo ── */
            item(span = StaggeredGridItemSpan.FullLine, key = "hero") {
                Column(
                    modifier = Modifier
                        .shadow(10.dp, RoundedCornerShape(8.dp))
                        .paperSurface(RoundedCornerShape(8.dp))
                        .padding(10.dp),
                ) {
                    // Cards show only the photo, so the title is announced here.
                    Text(
                        displayTitle(img.title) ?: "Untitled photo",
                        color = Ink.body,
                        fontFamily = cinzel(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(start = 2.dp, end = 2.dp, bottom = 10.dp),
                    )
                    Box(
                        Modifier
                            .sharedPhoto(img.id)
                            .fillMaxWidth()
                            .aspectRatio(ratio)
                            .clip(RoundedCornerShape(3.dp))
                            .background(Paper.imageWell),
                    ) {
                        // the grid thumbnail is already cached → paints instantly under the sharp one
                        AsyncImage(
                            model = img.thumb,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                        ComposeImage(
                            painter = heroPainter,
                            contentDescription = img.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(20.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.padding(top = 14.dp, start = 4.dp, end = 4.dp),
                    ) {
                        MetaItem("Source", img.sourceSite, Modifier.widthIn(max = 170.dp))
                        MetaItem("Type", img.filetype.uppercase().ifEmpty { "—" })
                        MetaItem("Dimensions", if (img.width > 0) "${img.width} × ${img.height}" else "—")
                        img.creator?.let { MetaItem("Creator", it, Modifier.widthIn(max = 170.dp)) }
                        img.license?.let { MetaItem("License", it, Modifier.widthIn(max = 170.dp)) }
                    }

                    Row(
                        Modifier.fillMaxWidth().padding(top = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        // Opens the original; on Android the system handles saving it.
                        BrassButton("Download", Modifier.weight(1f)) { uriHandler.openUri(img.full) }
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .paperField()
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                ) { uriHandler.openUri(img.sourceUrl) }
                                .padding(horizontal = 18.dp, vertical = 13.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                "SOURCE",
                                color = Ink.soft,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.8.sp,
                            )
                            Spacer(Modifier.size(8.dp))
                            Icon(Ico.External, Ink.soft, Modifier.size(16.dp))
                        }
                    }
                }
            }

            /* ── similar images ── */
            item(span = StaggeredGridItemSpan.FullLine, key = "similar") {
                Text(
                    "SIMILAR IMAGES",
                    style = TextStyle(
                        color = Ink.onLeather,
                        fontFamily = cinzel(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 3.sp,
                    ),
                    modifier = Modifier.padding(top = 14.dp, bottom = 2.dp, start = 2.dp),
                )
            }

            when (val rel = related) {
                null -> items(6) { i -> SkeletonCard(SKELETON_RATIOS[i % SKELETON_RATIOS.size], i) }
                else ->
                    if (rel.isEmpty()) {
                        item(span = StaggeredGridItemSpan.FullLine, key = "none") {
                            Text(
                                "No similar images found for this one.",
                                color = Ink.onLeatherSoft,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(6.dp),
                            )
                        }
                    } else {
                        itemsIndexed(rel, key = { _, r -> "rel-${r.id}" }) { index, r ->
                            PhotoCard(r, index) { onOpenImage(it) }
                        }
                    }
            }
        }
    }
}
