import AppShell from "@/components/app-shell";

export default function Page() {
  return <AppShell initial="home" />;
}
