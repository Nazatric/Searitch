import { NextRequest, NextResponse } from "next/server";
import { relatedImages } from "@/lib/providers";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const id = (sp.get("id") ?? "").slice(0, 120);
  const title = (sp.get("title") ?? "").slice(0, 200);
  const tags = (sp.get("tags") ?? "")
    .split(",")
    .map((t) => t.trim().toLowerCase())
    .filter(Boolean)
    .slice(0, 10);
  const thumb = (sp.get("thumb") ?? "").slice(0, 800);
  const ctx = (sp.get("ctx") ?? "").trim().slice(0, 120);
  if (!id) {
    return NextResponse.json({ error: "Missing id" }, { status: 400 });
  }
  try {
    const results = await relatedImages(id, title, tags, thumb, ctx);
    return NextResponse.json({ results });
  } catch (err) {
    return NextResponse.json(
      { error: `Related lookup failed: ${err instanceof Error ? err.message : "unknown"}` },
      { status: 502 },
    );
  }
}
