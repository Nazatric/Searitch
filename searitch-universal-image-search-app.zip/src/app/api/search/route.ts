import { NextRequest, NextResponse } from "next/server";
import { aggregateSearch, streamSearch, type SearchFilters } from "@/lib/providers";

export const runtime = "nodejs";

function pick<T extends string>(value: string | null, allowed: readonly T[], fallback: T): T {
  return allowed.includes((value ?? "") as T) ? ((value as T) ?? fallback) : fallback;
}

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const q = (sp.get("q") ?? "").trim().slice(0, 120);
  if (!q) {
    return NextResponse.json({ error: "Missing query" }, { status: 400 });
  }

  const filters: SearchFilters = {
    q,
    page: Math.min(Math.max(parseInt(sp.get("page") ?? "1", 10) || 1, 1), 20),
    type: pick(sp.get("type"), ["any", "jpg", "png", "gif", "svg", "transparent"] as const, "any"),
    aspect: pick(sp.get("aspect"), ["any", "tall", "wide", "square"] as const, "any"),
    size: pick(sp.get("size"), ["any", "small", "medium", "large"] as const, "any"),
    color: (sp.get("color") ?? "").slice(0, 16),
    license: pick(sp.get("license"), ["any", "commercial", "modification"] as const, "any"),
    provider: pick(
      sp.get("provider"),
      [
        "all", "openverse", "wikimedia", "wallhaven", "flickr",
        "inaturalist", "nasa", "met", "europeana", "vam",
      ] as const,
      "all",
    ),
    safe: sp.get("safe") === "0" || sp.get("safe") === "false" ? false : true,
    antiAi:
      sp.get("antiAi") === "0" ||
      sp.get("antiAi") === "false" ||
      sp.get("noai") === "0"
        ? false
        : true,
  };

  // Streaming mode: NDJSON, one line per source as soon as it answers.
  if (sp.get("stream") === "1") {
    const enc = new TextEncoder();
    let closed = false;
    const stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        const send = (o: unknown) => {
          if (closed) return;
          try {
            controller.enqueue(enc.encode(JSON.stringify(o) + "\n"));
          } catch {
            closed = true;
          }
        };
        try {
          const providers = await streamSearch(filters, (chunk) => send(chunk));
          send({ done: true, providers });
        } catch (err) {
          send({ error: err instanceof Error ? err.message : "Search failed" });
        } finally {
          if (!closed) controller.close();
          closed = true;
        }
      },
      cancel() {
        closed = true;
      },
    });
    return new Response(stream, {
      headers: {
        "Content-Type": "application/x-ndjson; charset=utf-8",
        "Cache-Control": "no-store",
        "X-Accel-Buffering": "no",
      },
    });
  }

  try {
    const { results, providers } = await aggregateSearch(filters);
    return NextResponse.json({ results, providers, page: filters.page });
  } catch (err) {
    return NextResponse.json(
      { error: `Search failed: ${err instanceof Error ? err.message : "unknown"}` },
      { status: 502 },
    );
  }
}
