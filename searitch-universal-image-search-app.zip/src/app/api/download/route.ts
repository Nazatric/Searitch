import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

// Streams a remote image through the server with a Content-Disposition
// attachment header so the browser saves it as a real file download.
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const rawUrl = sp.get("url") ?? "";
  const name = (sp.get("name") ?? "image").replace(/[^\w.\- ]/g, "_").slice(0, 120);

  let target: URL;
  try {
    target = new URL(rawUrl);
  } catch {
    return NextResponse.json({ error: "Invalid URL" }, { status: 400 });
  }
  if (target.protocol !== "https:" && target.protocol !== "http:") {
    return NextResponse.json({ error: "Unsupported protocol" }, { status: 400 });
  }
  const host = target.hostname;
  if (
    host === "localhost" ||
    host === "0.0.0.0" ||
    /^127\./.test(host) ||
    /^10\./.test(host) ||
    /^192\.168\./.test(host) ||
    /^172\.(1[6-9]|2\d|3[01])\./.test(host) ||
    host === "[::1]"
  ) {
    return NextResponse.json({ error: "Blocked host" }, { status: 400 });
  }

  try {
    const upstream = await fetch(target.toString(), {
      headers: { "User-Agent": "Searitch/1.0 (image downloader)" },
      signal: AbortSignal.timeout(30000),
    });
    if (!upstream.ok || !upstream.body) {
      return NextResponse.json(
        { error: `Source responded with ${upstream.status}` },
        { status: 502 },
      );
    }
    const contentType = upstream.headers.get("content-type") ?? "application/octet-stream";
    const ext = contentType.includes("png")
      ? "png"
      : contentType.includes("gif")
        ? "gif"
        : contentType.includes("svg")
          ? "svg"
          : contentType.includes("webp")
            ? "webp"
            : "jpg";
    const filename = name.includes(".") ? name : `${name}.${ext}`;

    return new NextResponse(upstream.body, {
      headers: {
        "Content-Type": contentType,
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (err) {
    return NextResponse.json(
      { error: `Download failed: ${err instanceof Error ? err.message : "unknown"}` },
      { status: 502 },
    );
  }
}
