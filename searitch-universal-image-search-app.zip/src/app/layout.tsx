import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { RippleListener, ToastHost } from "@/components/feedback";
// Textures are embedded as data URIs inside this stylesheet (render-blocking),
// so leather + paper exist on the first painted frame — no requests at all.
import "./textures.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "Searitch — Universal Image Search",
  description:
    "Search millions of real images from across the internet. Filter, preview, find visually similar images, download.",
};

export const viewport: Viewport = {
  themeColor: "#2b1a10",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        {/* Warm up the image CDNs that serve search results. */}
        <link rel="preconnect" href="https://upload.wikimedia.org" />
        <link rel="preconnect" href="https://live.staticflickr.com" />
        <link rel="preconnect" href="https://th.wallhaven.cc" />
      </head>
      <body className="antialiased">
        <RippleListener />
        {children}
        <ToastHost />
      </body>
    </html>
  );
}
