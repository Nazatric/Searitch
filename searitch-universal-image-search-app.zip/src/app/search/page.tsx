import AppShell from "@/components/app-shell";

// Deep link / refresh. Normal navigation never loads this route — it happens
// client-side inside the screen stack, so there is no fetch to wait for.
export default function Page() {
  return <AppShell initial="search" />;
}
