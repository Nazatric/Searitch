import { signatureOf, similarity, tagOverlap } from "@/lib/visual";
import { SOURCE_PROVIDERS, type SourceImage } from "@/lib/sources";
import { isAiGenerated, isMature } from "@/lib/content-safety";

// Searitch aggregation layer.
// Queries three real, keyless image APIs in parallel and normalizes results:
//  - Openverse  (api.openverse.org) — itself an index of 700M+ images from
//    Flickr, Wikimedia, museums, NASA, stock-photo sites and hundreds more.
//  - Wikimedia Commons (commons.wikimedia.org) — 100M+ media files.
//  - Wallhaven (wallhaven.cc) — community wallpaper site with color search.
// Nothing is faked: every result is a live record from these services.

export type SearitchImage = {
  id: string;
  provider: string;
  title: string;
  thumb: string;
  /** Lower-res thumbnail the UI falls back to if `thumb` fails to load. */
  thumbFallback?: string;
  /** Sharper rendition loaded progressively once the card is on screen. */
  thumbHi?: string;
  full: string;
  width: number;
  height: number;
  filetype: string;
  sourceSite: string;
  sourceUrl: string;
  creator?: string;
  license?: string;
  /** Source-supplied descriptive metadata used by Safe Search / Anti-AI checks. */
  description?: string;
  /** Real semantic tags/categories reported by the source itself. */
  tags: string[];
};

export type SearchFilters = {
  q: string;
  page: number;
  type: "any" | "jpg" | "png" | "gif" | "svg" | "transparent";
  aspect: "any" | "tall" | "wide" | "square";
  size: "any" | "small" | "medium" | "large";
  color: string; // key of COLOR_MAP or ""
  license: "any" | "commercial" | "modification";
  provider:
    | "all"
    | "openverse"
    | "wikimedia"
    | "wallhaven"
    | "flickr"
    | "inaturalist"
    | "nasa"
    | "met"
    | "europeana"
    | "vam";
  safe: boolean;   // default: true (always enabled)
  antiAi: boolean; // default: true (filters out AI-generated content)
};

export const COLOR_MAP: Record<
  string,
  { label: string; css: string; wallhaven: string; term: string }
> = {
  red: { label: "Red", css: "#c0392b", wallhaven: "cc0000", term: "red" },
  orange: { label: "Orange", css: "#e67e22", wallhaven: "ff9900", term: "orange" },
  yellow: { label: "Yellow", css: "#f1c40f", wallhaven: "ffcc33", term: "yellow" },
  green: { label: "Green", css: "#27ae60", wallhaven: "669900", term: "green" },
  teal: { label: "Teal", css: "#16a085", wallhaven: "66cccc", term: "teal" },
  blue: { label: "Blue", css: "#2980b9", wallhaven: "0066cc", term: "blue" },
  purple: { label: "Purple", css: "#8e44ad", wallhaven: "663399", term: "purple" },
  pink: { label: "Pink", css: "#e84393", wallhaven: "ea4c88", term: "pink" },
  brown: { label: "Brown", css: "#8d5a2b", wallhaven: "996633", term: "brown" },
  black: { label: "Black", css: "#1b1b1b", wallhaven: "000000", term: "black" },
  white: { label: "White", css: "#f5f0e6", wallhaven: "ffffff", term: "white" },
  gray: { label: "Gray", css: "#95a5a6", wallhaven: "999999", term: "gray" },
};

const UA = "Searitch/1.0 (universal image search; contact: searitch.app)";
const PAGE_SIZE = 20;

// ---------------------------------------------------------------- caching --
type CacheEntry = { at: number; data: SearitchImage[] };
const globalCache = globalThis as typeof globalThis & {
  __searitchCache?: Map<string, CacheEntry>;
};
const cache = (globalCache.__searitchCache ??= new Map());
const TTL = 10 * 60 * 1000;

function cacheGet(key: string): SearitchImage[] | null {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL) return hit.data;
  if (hit) cache.delete(key);
  return null;
}
function cacheSet(key: string, data: SearitchImage[]) {
  if (cache.size > 300) cache.clear();
  cache.set(key, { at: Date.now(), data });
}

// ---------------------------------------------------------------- helpers --
function extFromMime(mime?: string): string {
  if (!mime) return "";
  const map: Record<string, string> = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/gif": "gif",
    "image/svg+xml": "svg",
    "image/webp": "webp",
    "image/tiff": "tiff",
  };
  return map[mime] ?? mime.split("/")[1] ?? "";
}

function extFromUrl(url: string): string {
  const m = url.split("?")[0].match(/\.([a-z0-9]{2,5})$/i);
  const ext = m ? m[1].toLowerCase() : "";
  return ext === "jpeg" ? "jpg" : ext;
}

function stripHtml(html?: string): string {
  return html ? html.replace(/<[^>]*>/g, "").trim() : "";
}

function matchesAspect(img: SearitchImage, aspect: SearchFilters["aspect"]) {
  if (aspect === "any" || !img.width || !img.height) return true;
  const r = img.width / img.height;
  if (aspect === "wide") return r >= 1.2;
  if (aspect === "tall") return r <= 1 / 1.2;
  return r > 1 / 1.2 && r < 1.2;
}

function matchesSize(img: SearitchImage, size: SearchFilters["size"]) {
  if (size === "any" || !img.width || !img.height) return true;
  const mp = (img.width * img.height) / 1_000_000;
  if (size === "small") return mp < 1;
  if (size === "medium") return mp >= 1 && mp < 6;
  return mp >= 6;
}

function matchesType(img: SearitchImage, type: SearchFilters["type"]) {
  if (type === "any") return true;
  if (type === "transparent") return img.filetype === "png" || img.filetype === "svg";
  return img.filetype === type;
}

/**
 * Screening uses source-provided metadata. No source labels every AI/mature
 * item; this is a best-effort filter, not an image-classification claim.
 */
export { isAiGenerated, isMature };

export function matchesFilters(img: SearitchImage, f: SearchFilters): boolean {
  if (!matchesType(img, f.type)) return false;
  if (!matchesAspect(img, f.aspect)) return false;
  if (!matchesSize(img, f.size)) return false;
  if (f.safe && isMature(img)) return false;
  if (f.antiAi && isAiGenerated(img)) return false;
  return true;
}

async function getJson(url: string, timeoutMs = 9000): Promise<unknown> {
  const res = await fetch(url, {
    headers: { "User-Agent": UA, Accept: "application/json" },
    signal: AbortSignal.timeout(timeoutMs),
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`${res.status} from ${new URL(url).hostname}`);
  return res.json();
}

function colorTerm(f: SearchFilters): string {
  return f.color && COLOR_MAP[f.color] ? ` ${COLOR_MAP[f.color].term}` : "";
}

// -------------------------------------------------------------- openverse --
async function searchOpenverse(f: SearchFilters): Promise<SearitchImage[]> {
  const p = new URLSearchParams({
    q: f.q + colorTerm(f),
    page: String(f.page),
    page_size: String(PAGE_SIZE),
    mature: f.safe ? "false" : "true",
  });
  if (f.type === "transparent") p.set("extension", "png,svg");
  else if (f.type !== "any") p.set("extension", f.type);
  if (f.aspect !== "any") p.set("aspect_ratio", f.aspect);
  if (f.size !== "any") p.set("size", f.size);
  if (f.license !== "any") p.set("license_type", f.license);

  const json = (await getJson(
    `https://api.openverse.org/v1/images/?${p.toString()}`,
  )) as { results?: Array<Record<string, unknown>> };

  return (json.results ?? []).map((r) => mapOpenverse(r));
}

function tagNames(raw: unknown, limit = 8): string[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((t) => {
      if (typeof t === "string") return t;
      if (t && typeof t === "object") return String((t as Record<string, unknown>).name ?? "");
      return "";
    })
    .map((t) => t.trim().toLowerCase())
    .filter((t) => t.length > 1 && t.length <= 30)
    .slice(0, limit);
}

// Wikimedia categories are dominated by licensing/maintenance noise
// ("GFDL", "Attribution only license", "Media missing description"…). Those
// are useless for similarity, so strip them and keep only content terms.
const JUNK_CATEGORY =
  /^(hidden|cs1|wikipedia|all |articles|featured|quality|valued|attribution|gfdl|cc[- ]|creative commons|license|licen[cs]e|self-published|public domain|files? with|images? with|media (missing|without|needing)|needs |missing |uploaded with|created with|derivative|migration|supported by|maintained|pages? |wikiproject|commons?[- ]|free |restricted|permission|copy(left|right)|pd-|deletion|disambig|stub)/i;

function categoriesToTags(html?: string): string[] {
  if (!html) return [];
  const clean = html
    .replace(/<[^>]*>/g, " ")
    .split(/[|,;]/)
    .map((c) =>
      c
        .replace(/^Category:/i, "")
        .replace(/_/g, " ")
        .replace(/\s*\([^)]*\)\s*/g, " ")
        .trim()
        .toLowerCase(),
    )
    .filter((c) => c.length > 2 && c.length <= 30 && !JUNK_CATEGORY.test(c));
  // Prefer the most specific (longest) content terms.
  return [...new Set(clean)].sort((a, b) => b.length - a.length).slice(0, 8);
}

export function mapOpenverse(r: Record<string, unknown>): SearitchImage {
  const url = String(r.url ?? "");
  // NEVER use r.thumbnail: Openverse's thumbnail proxy lives on the API host
  // and can hang for tens of seconds, which stalls the whole grid. The
  // original url is served by the source site and is fast.
  const proxy = String(r.thumbnail ?? "");
  const original = url || proxy;
  return {
    tags: tagNames(r.tags),
    id: `openverse:${String(r.id ?? "")}`,
    provider: "openverse",
    title: String(r.title ?? "Untitled"),
    thumb: original,
    thumbFallback: original,
    full: original,
    width: Number(r.width ?? 0),
    height: Number(r.height ?? 0),
    filetype: String(r.filetype ?? "") || extFromUrl(url),
    sourceSite: String(r.source ?? r.provider ?? "openverse").replace(/_/g, " "),
    sourceUrl: String(r.foreign_landing_url ?? url),
    creator: r.creator ? String(r.creator) : undefined,
    description: r.description ? String(r.description).slice(0, 3000) : undefined,
    license: r.license
      ? `${String(r.license).toUpperCase()} ${String(r.license_version ?? "")}`.trim()
      : undefined,
  };
}

// -------------------------------------------------------------- wikimedia --
const MIME_FOR_TYPE: Record<string, string> = {
  jpg: "image/jpeg",
  png: "image/png",
  gif: "image/gif",
  svg: "image/svg+xml",
  transparent: "image/png",
};

async function searchWikimedia(f: SearchFilters): Promise<SearitchImage[]> {
  let search = f.q + colorTerm(f);
  if (f.type !== "any") search += ` filemime:${MIME_FOR_TYPE[f.type]}`;

  const p = new URLSearchParams({
    action: "query",
    format: "json",
    origin: "*",
    generator: "search",
    gsrsearch: search,
    gsrnamespace: "6",
    gsrlimit: String(PAGE_SIZE),
    gsroffset: String((f.page - 1) * PAGE_SIZE),
    prop: "imageinfo",
    iiprop: "url|size|mime|extmetadata",
    iiurlwidth: "640",
  });

  const json = (await getJson(
    `https://commons.wikimedia.org/w/api.php?${p.toString()}`,
  )) as {
    query?: { pages?: Record<string, Record<string, unknown>> };
  };

  const pages = Object.values(json.query?.pages ?? {});
  const out: SearitchImage[] = [];
  for (const page of pages) {
    const infoArr = page.imageinfo as Array<Record<string, unknown>> | undefined;
    const info = infoArr?.[0];
    if (!info) continue;
    const mime = String(info.mime ?? "");
    if (!mime.startsWith("image/")) continue;
    const meta = (info.extmetadata ?? {}) as Record<string, { value?: string }>;
    const title = String(page.title ?? "")
      .replace(/^File:/, "")
      .replace(/\.[a-z0-9]+$/i, "");
    const img: SearitchImage = {
      tags: categoriesToTags(meta.Categories?.value),
      description: stripHtml(meta.ImageDescription?.value) || undefined,
      id: `wikimedia:${String(page.pageid ?? "")}`,
      provider: "wikimedia",
      title: title || "Untitled",
      thumb: String(info.thumburl ?? info.url ?? ""),
      full: String(info.url ?? ""),
      width: Number(info.width ?? 0),
      height: Number(info.height ?? 0),
      filetype: extFromMime(mime),
      sourceSite: "Wikimedia Commons",
      sourceUrl: String(info.descriptionurl ?? info.url ?? ""),
      creator: stripHtml(meta.Artist?.value) || undefined,
      license: meta.LicenseShortName?.value || undefined,
    };
    // Commons search has no native aspect/size params — filter honestly here.
    if (matchesAspect(img, f.aspect) && matchesSize(img, f.size)) out.push(img);
  }
  return out;
}

// -------------------------------------------------------------- wallhaven --
async function searchWallhaven(f: SearchFilters): Promise<SearitchImage[]> {
  // Wallhaven art is not openly licensed — exclude it when a license filter
  // is active. It also only serves large JPG/PNG wallpapers.
  if (f.license !== "any") return [];
  if (f.type === "gif" || f.type === "svg" || f.type === "transparent") return [];
  if (f.size === "small") return [];

  const p = new URLSearchParams({
    q: f.q,
    page: String(f.page),
    purity: f.safe ? "100" : "110",
    categories: "111",
    sorting: "relevance",
  });
  if (f.color && COLOR_MAP[f.color]) p.set("colors", COLOR_MAP[f.color].wallhaven);
  if (f.aspect === "wide") p.set("ratios", "landscape");
  if (f.aspect === "tall") p.set("ratios", "portrait");
  if (f.aspect === "square") p.set("ratios", "1x1");
  if (f.size === "large") p.set("atleast", "2560x1440");

  const json = (await getJson(
    `https://wallhaven.cc/api/v1/search?${p.toString()}`,
  )) as { data?: Array<Record<string, unknown>> };

  const out: SearitchImage[] = [];
  for (const r of json.data ?? []) {
    const ft = extFromMime(String(r.file_type ?? ""));
    if (f.type !== "any" && ft !== f.type) continue;
    const thumbs = (r.thumbs ?? {}) as Record<string, string>;
    out.push({
      tags: tagNames(r.tags),
      id: `wallhaven:${String(r.id ?? "")}`,
      provider: "wallhaven",
      title: `Wallpaper ${Number(r.dimension_x ?? 0)}×${Number(r.dimension_y ?? 0)}`,
      // 'large' is a 16:9 crop (432px) — right for landscape. Portrait/square
      // use 'original' which keeps the true aspect (Wallhaven caps it ~300px).
      thumb:
        (Number(r.dimension_x ?? 0) / Math.max(1, Number(r.dimension_y ?? 1)) >= 1.25
          ? (thumbs.large ?? thumbs.original ?? thumbs.small)
          : (thumbs.original ?? thumbs.large ?? thumbs.small)) ?? String(r.path ?? ""),
      thumbFallback: thumbs.small,
      thumbHi:
        Number(r.dimension_x ?? 0) / Math.max(1, Number(r.dimension_y ?? 1)) < 1.25 && r.path
          ? `/_next/image?url=${encodeURIComponent(String(r.path))}&w=640&q=75`
          : undefined,
      full: String(r.path ?? ""),
      width: Number(r.dimension_x ?? 0),
      height: Number(r.dimension_y ?? 0),
      filetype: ft,
      sourceSite: "Wallhaven",
      sourceUrl: String(r.url ?? r.path ?? ""),
    });
  }
  return out;
}

// ----------------------------------------------------------------- flickr --
async function searchFlickr(f: SearchFilters): Promise<SearitchImage[]> {
  // Flickr's public feed has no safe-rating parameter or mature metadata.
  // Strict Safe Search therefore excludes it rather than guessing.
  if (f.safe) return [];
  // The public feed is JPG-only, has no paging and reports no dimensions.
  if (f.page > 1) return [];
  if (f.type !== "any" && f.type !== "jpg") return [];
  if (f.license !== "any") return [];
  if (f.aspect !== "any" || f.size !== "any") return [];

  const tags = [f.q.trim().replace(/\s+/g, ","), colorTerm(f).trim()]
    .filter(Boolean)
    .join(",");
  const url = `https://api.flickr.com/services/feeds/photos_public.gne?tags=${encodeURIComponent(
    tags,
  )}&format=json&nojsoncallback=1`;

  const res = await fetch(url, {
    headers: { "User-Agent": UA },
    signal: AbortSignal.timeout(8000),
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`${res.status} from api.flickr.com`);
  // Flickr feeds escape single quotes with \' which is invalid JSON — repair.
  const text = (await res.text()).replace(/\\'/g, "'");
  const json = JSON.parse(text) as {
    items?: Array<{
      title?: string;
      link?: string;
      media?: { m?: string };
      author?: string;
      description?: string;
    }>;
  };

  const out: SearitchImage[] = [];
  for (const item of json.items ?? []) {
    const thumb = item.media?.m ?? "";
    if (!thumb) continue;
    const link = item.link ?? thumb;
    const photoId = link.match(/\/(\d{6,})\/?/)?.[1] ?? thumb;
    const creator = item.author?.match(/\("?([^")]+)"?\)/)?.[1];
    out.push({
      tags: [],
      id: `flickr:${photoId}`,
      provider: "flickr",
      title: (item.title ?? "").trim() || "Untitled",
      // _m is only 240px (blurry on retina). _z is 640px; keep _m as fallback
      // for photos whose original is too small to have a _z rendition.
      thumb: thumb.replace(/_m\.(jpg|png|gif)$/i, "_z.$1"),
      thumbFallback: thumb,
      full: thumb.replace("_m.", "_b."),
      width: 0,
      height: 0,
      filetype: extFromUrl(thumb) || "jpg",
      sourceSite: "Flickr",
      sourceUrl: link,
      creator,
      description: stripHtml(item.description).slice(0, 3000),
    });
  }
  return out;
}


/* ═══════════════ direct source providers (billion-image catalogue) ═══════
   Each site below is queried directly, in parallel. Openverse's own endpoint
   is often slow because it fans out to all 52 of its sites; hitting the
   underlying APIs ourselves is both faster and gives us per-source control. */

function fromSourceImage(s: SourceImage): SearitchImage {
  return {
    id: s.id,
    provider: s.provider,
    title: s.title,
    thumb: s.thumb,
    thumbFallback: s.thumbFallback,
    full: s.full,
    width: s.width,
    height: s.height,
    filetype: s.filetype,
    sourceSite: s.sourceSite,
    sourceUrl: s.sourceUrl,
    creator: s.creator,
    license: s.license,
    description: s.description,
    tags: s.tags,
  };
}

/**
 * Queries every direct source in parallel and returns each source's results as
 * soon as THAT source answers — the first photos are not held back by the
 * slowest site.
 */
async function searchDirectSources(
  f: SearchFilters,
  emit?: (chunk: SearitchImage[]) => void,
): Promise<SearitchImage[]> {
  const wanted = SOURCE_PROVIDERS.filter((p) => {
    if (f.provider === "all") return true;
    if (f.provider === p.key) return true;
    if (f.provider === "wikimedia") {
      // Museums & heritage sites are the same family as Wikimedia Commons.
      return ["met", "europeana", "vam"].includes(p.key);
    }
    return false;
  });
  if (wanted.length === 0) return [];

  const out: SearitchImage[] = [];
  await Promise.all(
    wanted.map(async (p) => {
      try {
        const list = await withDeadline(p.run(f.q), deadlineFor(p.key));
        sourceStatus[`src:${p.key}`] = `ok (${list.length})`;
        const mapped = list.map(fromSourceImage);
        out.push(...mapped);
        if (mapped.length > 0) emit?.(mapped);
      } catch {
        sourceStatus[`src:${p.key}`] = "error";
      }
    }),
  );
  return out;
}

const sourceStatus: Record<string, string> = {};

// -------------------------------------------------------------- aggregate --
function withDeadline<T>(p: Promise<T>, ms: number): Promise<T> {
  return Promise.race([
    p,
    new Promise<T>((_, reject) =>
      setTimeout(() => reject(new Error("source deadline exceeded")), ms),
    ),
  ]);
}

/* Circuit breaker: a source that keeps timing out gets a tiny budget so it
   can never stall a search again — and recovers automatically. */
type Health = { fails: number; openUntil: number };
const globalHealth = globalThis as typeof globalThis & {
  __searitchHealth?: Map<string, Health>;
};
const health = (globalHealth.__searitchHealth ??= new Map<string, Health>());

const HEALTHY_BUDGET: Record<string, number> = {
  openverse: 3500,
  wikimedia: 4500,
  wallhaven: 3500,
  flickr: 3500,
  // The direct source APIs are small JSON endpoints — they answer fast.
  sources: 4500,
  inaturalist: 4000,
  europeana: 4000,
  nasa: 4000,
  met: 4500,
  vam: 4000,
};

function deadlineFor(name: string): number {
  const h = health.get(name);
  return h && h.openUntil > Date.now() ? 400 : (HEALTHY_BUDGET[name] ?? 3500);
}

function recordResult(name: string, ok: boolean) {
  const h = health.get(name) ?? { fails: 0, openUntil: 0 };
  if (ok) {
    h.fails = 0;
    h.openUntil = 0;
  } else {
    h.fails += 1;
    if (h.fails >= 2) h.openUntil = Date.now() + 5 * 60_000;
  }
  health.set(name, h);
}

/** How long we let the *whole* search wait on stragglers. */
const EARLY_RETURN_MS = 2500;
/** After the first source with results answers, wait at most this long for the rest. */
const GRACE_MS = 1500;

function interleave(lists: SearitchImage[][]): SearitchImage[] {
  const out: SearitchImage[] = [];
  const seen = new Set<string>();
  const max = Math.max(0, ...lists.map((l) => l.length));
  for (let i = 0; i < max; i++) {
    for (const list of lists) {
      const img = list[i];
      if (!img || !img.thumb || !img.full) continue;
      if (seen.has(img.full)) continue;
      seen.add(img.full);
      out.push(img);
    }
  }
  return out;
}

export async function aggregateSearch(
  f: SearchFilters,
): Promise<{ results: SearitchImage[]; providers: Record<string, string> }> {
  const key = JSON.stringify(f);
  const cached = cacheGet(key);
  const status: Record<string, string> = {};
  if (cached) return { results: cached, providers: { cache: "hit" } };

  const tasks: Array<{ name: string; run: () => Promise<SearitchImage[]> }> = [];
  const want = (n: SearchFilters["provider"]) => f.provider === "all" || f.provider === n;
  if (want("openverse")) tasks.push({ name: "openverse", run: () => searchOpenverse(f) });
  if (want("wikimedia")) tasks.push({ name: "wikimedia", run: () => searchWikimedia(f) });
  if (want("wallhaven")) tasks.push({ name: "wallhaven", run: () => searchWallhaven(f) });
  if (want("flickr")) tasks.push({ name: "flickr", run: () => searchFlickr(f) });
  // The remaining sites (iNaturalist, NASA, the Met, Europeana, Rawpixel,
  // Smithsonian, StockSnap, Phylopic) are queried directly, in one parallel fan.
  tasks.push({ name: "sources", run: () => searchDirectSources(f) });

  // Per-source deadlines + early return: one slow upstream can never stall
  // the page. Whatever has answered within EARLY_RETURN_MS is returned.
  const state: Array<SearitchImage[] | null> = tasks.map(() => null);
  const promises = tasks.map((t, i) =>
    withDeadline(t.run(), deadlineFor(t.name)).then(
      (r) => {
        state[i] = r;
        recordResult(t.name, true);
        status[t.name] = `ok (${r.length})`;
        return r;
      },
      (err) => {
        state[i] = [];
        recordResult(t.name, false);
        status[t.name] = `error: ${String(err?.message ?? err)}`;
        return [] as SearitchImage[];
      },
    ),
  );

  await new Promise<void>((resolve) => {
    if (promises.length === 0) return resolve();
    let finished = 0;
    let grace: ReturnType<typeof setTimeout> | undefined;
    const hard = setTimeout(resolve, EARLY_RETURN_MS);
    const done = () => {
      clearTimeout(hard);
      if (grace) clearTimeout(grace);
      resolve();
    };
    promises.forEach((p) =>
      p.then((list) => {
        finished++;
        if (finished === promises.length) return done();
        if (list.length > 0 && !grace) grace = setTimeout(done, GRACE_MS);
      }),
    );
  });

  const finalize = (lists: Array<SearitchImage[] | null>) =>
    interleave(lists.map((l) => l ?? [])).filter((img) => matchesFilters(img, f));

  const results = finalize(state);

  // When the stragglers finally land, upgrade the cache with the full set.
  void Promise.all(promises)
    .then((all) => {
      const full = finalize(all);
      if (full.length > results.length) cacheSet(key, full);
    })
    .catch(() => undefined);

  if (results.length > 0) cacheSet(key, results);
  return { results, providers: status };
}

// ---------------------------------------------------------------- related --
function titleKeywords(title: string): string[] {
  return title
    .replace(/[_\-.]/g, " ")
    .replace(/[^\p{L}\p{N} ]/gu, "")
    .toLowerCase()
    .split(/\s+/)
    .filter((w) => w.length > 2 && !/^\d+$/.test(w));
}

/**
 * Smart "similar images". Two independent signals, combined:
 *
 * 1. SEMANTIC — the candidate pool is built from the image's real provider
 *    tags/categories (not its filename), or Openverse's own related endpoint
 *    when the image came from there.
 * 2. VISUAL — every candidate is downsampled and compared to the target with
 *    a 64-bit dHash plus an 8-bin colour palette, so results that actually
 *    *look* alike rise to the top.
 */
export async function relatedImages(
  id: string,
  title: string,
  tags: string[] = [],
  thumb = "",
  ctx = "",
): Promise<SearitchImage[]> {
  const [provider, rawId] = id.split(":");
  const cacheKey = `related:${id}`;
  const cached = cacheGet(cacheKey);
  if (cached) return cached;

  // Start hashing the target immediately — it runs in parallel with the search.
  const targetImgPromise = (async (): Promise<SearitchImage | null> => {
    if (provider !== "openverse" || !rawId) return null;
    try {
      const json = (await getJson(
        `https://api.openverse.org/v1/images/${rawId}/?related=false`,
        6000,
      )) as Record<string, unknown>;
      return json.id ? mapOpenverse(json) : null;
    } catch {
      return null;
    }
  })();

  const [targetMeta] = await Promise.all([targetImgPromise]);
  // The caller passes the thumbnail we already displayed, so the target can be
  // hashed for *any* provider — visual similarity is never skipped.
  const targetUrl = thumb || targetMeta?.thumb || "";
  const targetTags = tags.length > 0 ? tags : (targetMeta?.tags ?? []);
  const targetWords = titleKeywords(title);
  const targetSigPromise = targetUrl ? signatureOf(targetUrl) : Promise.resolve(null);

  // ── candidate pool ──
  let pool: SearitchImage[] = [];

  if (provider === "openverse" && rawId) {
    try {
      const json = (await getJson(
        `https://api.openverse.org/v1/images/${rawId}/related/?page_size=20`,
      )) as { results?: Array<Record<string, unknown>> };
      pool = (json.results ?? []).map((r) => mapOpenverse(r));
    } catch {
      pool = [];
    }
  }

  if (pool.length < 12) {
    // Always try BOTH signals: real provider tags (semantic) and the image's
    // title keywords. Whichever yields content wins; both merge.
    // Title keywords are the most descriptive signal a source gives us;
    // tags are noisy (years, licences, language categories) so they only
    // extend the pool when the title alone isn't enough.
    const queries = [
      targetWords.slice(0, 4).join(" "),
      [...targetWords.slice(0, 2), ...targetTags.slice(0, 2)].join(" "),
      targetTags.slice(0, 3).join(" "),
    ].filter((q, i, all) => q.trim().length > 3 && all.indexOf(q) === i).slice(0, 2);

    const found = await Promise.all(
      queries.map((q) =>
        aggregateSearch({
          q,
          page: 1,
          type: "any",
          aspect: "any",
          size: "any",
          color: "",
          license: "any",
          provider: "all",
          safe: true,
          antiAi: true,
        }).then((r) => r.results),
      ),
    );
    const seen = new Set(pool.map((p) => p.full));
    for (const list of found) {
      for (const f of list) if (!seen.has(f.full)) { seen.add(f.full); pool.push(f); }
    }
  }

  // Obscure titles (serial numbers, file names) leave the pool thin. Fall back
  // to the search the user is browsing: the images from that same search that
  // LOOK most like this one are still genuinely relevant.
  if (pool.length < 12 && ctx.length > 1) {
    const { results: found } = await aggregateSearch({
      q: ctx,
      page: 1,
      type: "any",
      aspect: "any",
      size: "any",
      color: "",
      license: "any",
      provider: "all",
      safe: true,
      antiAi: true,
    });
    const seen = new Set(pool.map((p) => p.full));
    for (const f of found) if (!seen.has(f.full)) { seen.add(f.full); pool.push(f); }
  }

  const candidates = pool.filter((c) => c.id !== id && c.thumb).slice(0, 24);
  if (candidates.length === 0) return [];

  // ── visual re-ranking (bounded: at most 14 hashes, all in parallel) ──
  const targetSig = await targetSigPromise;
  const toHash = candidates.slice(0, 18);
  const sigs = await Promise.all(
    toHash.map((c) => signatureOf(c.thumb).catch(() => null)),
  );
  const sigById = new Map<string, Awaited<ReturnType<typeof signatureOf>>>();
  toHash.forEach((c, i) => sigById.set(c.id, sigs[i]));

  const scored = candidates.map((c) => {
    const visual = targetSig ? similarity(targetSig, sigById.get(c.id) ?? null) : 0;
    const semanticScore = Math.max(
      tagOverlap(targetWords, titleKeywords(c.title)),
      tagOverlap(targetTags, c.tags) * 0.6,
    );
    // Visual evidence dominates when we have it; otherwise fall back to semantics.
    const score = targetSig && sigById.has(c.id)
      ? visual * 0.6 + semanticScore * 0.4
      : semanticScore;
    return { c, score };
  });

  scored.sort((a, b) => b.score - a.score);
  // Never return an empty grid when real candidates exist — rank, don't gate.
  const results = scored.slice(0, 18).map((s) => s.c);

  if (results.length > 0) cacheSet(cacheKey, results);
  return results;
}


// ---------------------------------------------------------- streaming search --
/** First paint is gathered for this long so it can mix sources (round-robin). */
const GATHER_MS = 200;

/**
 * Same sources and filters as `aggregateSearch`, but results are streamed:
 * the first batch goes out ~GATHER_MS after the first source answers
 * (interleaved across sources, so the opening screen is a real mix of sites
 * rather than whoever happened to be fastest); slower sources follow the
 * moment they answer. Dead/slow sources obey the per-source deadline and the
 * circuit breaker.
 */
export async function streamSearch(
  f: SearchFilters,
  emit: (chunk: { p: string; r: SearitchImage[] }) => void,
): Promise<Record<string, string>> {
  const key = JSON.stringify(f);
  const cached = cacheGet(key);
  if (cached) {
    emit({ p: "cache", r: cached });
    return { cache: "hit" };
  }

  const want = (n: SearchFilters["provider"]) => f.provider === "all" || f.provider === n;
  const tasks: Array<{ name: string; run: () => Promise<SearitchImage[]> }> = [];
  if (want("openverse")) tasks.push({ name: "openverse", run: () => searchOpenverse(f) });
  if (want("wikimedia")) tasks.push({ name: "wikimedia", run: () => searchWikimedia(f) });
  if (want("wallhaven")) tasks.push({ name: "wallhaven", run: () => searchWallhaven(f) });
  if (want("flickr")) tasks.push({ name: "flickr", run: () => searchFlickr(f) });

  const seen = new Set<string>();
  const all: SearitchImage[] = [];
  const status: Record<string, string> = { ...sourceStatus };
  const gathered: SearitchImage[][] = [];
  let flushed = false;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let finished = 0;

  // The direct sources (iNaturalist, NASA, the Met, Europeana, V&A) stream individually.
  const directTask = searchDirectSources(f, (chunk) => {
    const fresh = chunk.filter(
      (img) => img.thumb && img.full && !seen.has(img.full) && matchesFilters(img, f),
    );
    fresh.forEach((img) => seen.add(img.full));
    if (fresh.length === 0) return;
    all.push(...fresh);
    if (flushed) {
      emit({ p: "sources", r: fresh });
    } else {
      gathered.push(fresh);
      if (!timer) timer = setTimeout(flush, GATHER_MS);
    }
  });

  const flush = () => {
    if (flushed) return;
    flushed = true;
    if (timer) clearTimeout(timer);
    const mixed = interleave(gathered);
    if (mixed.length > 0) emit({ p: "first", r: mixed });
  };

  /** Emit one source immediately (no gather wait) — the fastest site wins. */
  const flushNow = (list: SearitchImage[]) => {
    if (flushed || list.length === 0) return;
    flushed = true;
    if (timer) clearTimeout(timer);
    emit({ p: "first", r: list });
  };

  await Promise.all([
    directTask,
    ...tasks.map(async (t) => {
      try {
        const list = await withDeadline(t.run(), deadlineFor(t.name));
        recordResult(t.name, true);
        status[t.name] = `ok (${list.length})`;
        const fresh = list.filter(
          (img) => img.thumb && img.full && !seen.has(img.full) && matchesFilters(img, f),
        );
        fresh.forEach((img) => seen.add(img.full));
        if (fresh.length > 0) {
          all.push(...fresh);
          if (flushed) {
            emit({ p: t.name, r: fresh });
          } else {
            gathered.push(fresh);
            // The very first source to answer paints immediately — no waiting
            // for the gather window. Later sources are folded in after the
            // window so the opening grid ends up mixing several sites.
            if (gathered.length === 1) {
              flushNow(fresh);
            } else if (!timer) {
              timer = setTimeout(flush, GATHER_MS);
            }
          }
        }
      } catch (err) {
        recordResult(t.name, false);
        status[t.name] = `error: ${String((err as Error)?.message ?? err)}`;
      } finally {
        finished++;
        if (finished === tasks.length) flush();
      }
    }),
  ]);
  flush();

  if (all.length > 0) cacheSet(key, all);
  return status;
}
