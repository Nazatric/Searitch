"use client";

import { useSyncExternalStore } from "react";

const BP3 = "(min-width: 640px)";
const BP4 = "(min-width: 1024px)";

function subscribe(cb: () => void) {
  const a = window.matchMedia(BP3);
  const b = window.matchMedia(BP4);
  a.addEventListener("change", cb);
  b.addEventListener("change", cb);
  return () => {
    a.removeEventListener("change", cb);
    b.removeEventListener("change", cb);
  };
}

function snapshot(): number {
  if (window.matchMedia(BP4).matches) return 4;
  if (window.matchMedia(BP3).matches) return 3;
  return 2;
}

/** Responsive masonry column count (2 → 3 → 4), SSR-safe via useSyncExternalStore. */
export function useColumnCount(max = 4): number {
  const n = useSyncExternalStore(subscribe, snapshot, () => 2);
  return Math.min(n, max);
}
