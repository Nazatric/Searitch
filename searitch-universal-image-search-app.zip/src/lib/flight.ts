// Shared-element "flights": a card's photo physically lifts out of the grid and
// grows into the detail page (and shrinks back on return). Pure DOM + Web
// Animations — transform and clip-path only, so it runs on the compositor.

export type Rect = {
  /** Axis-aligned visual bounds (used for viewport tests). */
  x: number;
  y: number;
  w: number;
  h: number;
  /** Untransformed local box size; transform scales are recorded separately. */
  localW?: number;
  localH?: number;
  /** Computed print transform, including an entrance/hover scale if in progress. */
  rotation?: number;
  scaleX?: number;
  scaleY?: number;
};

function transformOf(el: Element): { rotation: number; scaleX: number; scaleY: number } {
  const owner = el.closest<HTMLElement>(".print") ?? el as HTMLElement;
  const t = getComputedStyle(owner).transform;
  if (!t || t === "none") return { rotation: 0, scaleX: 1, scaleY: 1 };
  try {
    const m = new DOMMatrixReadOnly(t);
    return {
      rotation: (Math.atan2(m.b, m.a) * 180) / Math.PI,
      scaleX: Math.hypot(m.a, m.b),
      scaleY: Math.hypot(m.c, m.d),
    };
  } catch {
    return { rotation: 0, scaleX: 1, scaleY: 1 };
  }
}

export function rectOf(el: Element): Rect {
  const r = el.getBoundingClientRect();
  const h = el as HTMLElement;
  const style = getComputedStyle(h);
  const localW = Number.parseFloat(style.width) || h.offsetWidth || r.width;
  const localH = Number.parseFloat(style.height) || h.offsetHeight || r.height;
  const transform = transformOf(el);
  return {
    x: r.left,
    y: r.top,
    w: r.width,
    h: r.height,
    localW,
    localH,
    ...transform,
  };
}

/** Is a meaningful part of the rect on screen (below `topInset`)? */
export function inView(r: Rect, topInset = 0): boolean {
  return (
    r.w > 8 &&
    r.h > 8 &&
    r.y + r.h > topInset + 12 &&
    r.y < window.innerHeight - 12 &&
    r.x + r.w > 0 &&
    r.x < window.innerWidth
  );
}

/* ─────────────────────────── real spring physics ─────────────────────────
   A damped harmonic oscillator sampled into a CSS `linear()` easing, so the
   zoom genuinely settles like a spring (a hair of overshoot) instead of
   following a canned cubic-bezier. Duration comes from the physics.        */

type Spring = { duration: number; easing: string };
const springs = new Map<string, Spring>();

export function spring(stiffness: number, damping: number): Spring {
  const key = `${stiffness}/${damping}`;
  const hit = springs.get(key);
  if (hit) return hit;

  const w0 = Math.sqrt(stiffness);
  const z = damping / (2 * w0);
  const x = (t: number) => {
    if (z >= 0.999) return 1 - Math.exp(-w0 * t) * (1 + w0 * t);
    const wd = w0 * Math.sqrt(1 - z * z);
    return 1 - Math.exp(-z * w0 * t) * (Math.cos(wd * t) + ((z * w0) / wd) * Math.sin(wd * t));
  };
  // Settle = the last moment the spring is still visibly moving. We keep
  // recording until the motion is imperceptible, so the flight never ends in a
  // dead frame — the last frame it renders is already (almost) the rest
  // position, and the hand-over to the hero is invisible.
  let settle = 0.1;
  for (let t = 0.02; t < 2.5; t += 0.002) if (Math.abs(1 - x(t)) > 0.0004) settle = t;
  settle = Math.min(1.6, settle + 0.08);

  const N = 140;
  const pts: string[] = [];
  for (let i = 0; i <= N; i++) {
    const t = (settle * i) / N;
    // Ease the very end into the rest position so the motion is still
    // advancing in the final frames — no dead stop, no visible "settle".
    const v = i === N ? 1 : x(t);
    pts.push(String(Math.round(v * 1000000) / 1000000));
  }
  pts[N] = "1";

  const linearOk =
    typeof CSS !== "undefined" &&
    typeof CSS.supports === "function" &&
    CSS.supports("animation-timing-function", "linear(0, 1)");

  const out: Spring = linearOk
    ? { duration: Math.round(settle * 1000), easing: `linear(${pts.join(", ")})` }
    : { duration: Math.min(520, Math.round(settle * 1000)), easing: "cubic-bezier(0.22, 1, 0.36, 1)" };
  springs.set(key, out);
  return out;
}

const reduced = () =>
  typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;

export type Flight = { done: Promise<void>; remove: () => void; cancel: () => void };

/**
 * Animate a photo between a small rect (a grid card) and a big rect (the
 * detail hero). The flyer is laid out at the BIG rect and scaled/clipped down
 * to the small one, so there is no layout work per frame and no distortion:
 * uniform scale + a centred clip reproduces the card's object-fit: cover crop.
 */
export function fly(o: {
  src: string;
  big: Rect;
  small: Rect;
  dir: "in" | "out";
  smallRadius: number;
  bigRadius: number;
}): Flight {
  const { big, small } = o;
  // A print is rotated in the grid. getBoundingClientRect() returns its AABB,
  // not the original photo box — using that AABB as the endpoint is exactly
  // what makes the exiting photo visibly clip at the end. Use the card's local
  // (unrotated) image box, rotate the flyer by the same amount, and keep the
  // AABB only for viewport tests.
  const targetW = (small.localW ?? small.w) * (small.scaleX ?? 1);
  const targetH = (small.localH ?? small.h) * (small.scaleY ?? 1);
  const angle = small.rotation ?? 0;
  const s = Math.max(targetW / big.w, targetH / big.h);
  const dx = small.x + small.w / 2 - (big.x + big.w / 2);
  const dy = small.y + small.h / 2 - (big.y + big.h / 2);
  const ix = Math.max(0, (big.w - targetW / s) / 2);
  const iy = Math.max(0, (big.h - targetH / s) / 2);

  const el = document.createElement("div");
  el.className = "flyer";
  Object.assign(el.style, {
    position: "fixed",
    left: `${big.x}px`,
    top: `${big.y}px`,
    width: `${big.w}px`,
    height: `${big.h}px`,
    transformOrigin: "50% 50%",
    zIndex: "10000",
    pointerEvents: "none",
    overflow: "hidden",
    contain: "layout paint",
    background: "#cdbf9f",
  });
  const img = document.createElement("img");
  img.src = o.src;
  img.alt = "";
  img.decoding = "sync";
  Object.assign(img.style, { width: "100%", height: "100%", objectFit: "cover", display: "block" });
  el.appendChild(img);
  document.body.appendChild(el);

  const smallF = {
    // Translate the flyer center to the card image center, then match the
    // card's rotation and scale. Because the card's LOCAL dimensions are used,
    // the clipped image lands exactly inside the rotated print window.
    transform: `translate(${dx}px, ${dy}px) rotate(${angle}deg) scale(${s})`,
    clipPath: `inset(${iy}px ${ix}px round ${o.smallRadius / s}px)`,
  };
  const bigF = {
    transform: "translate(0px, 0px) rotate(0deg) scale(1)",
    clipPath: `inset(0px 0px round ${o.bigRadius}px)`,
  };
  // A critically-ish damped spring, sampled into a linear() easing. The
  // flight ends exactly where the hero sits, with the last frames still moving
  // (no dead stop) — the image is then handed over with zero visible jump.
  // A slightly under-damped spring so the photo arrives with a hint of
  // momentum. The easing's last samples keep advancing, so the flight never
  // ends in a dead frame — the hand-over to the hero is invisible.
  const sp = o.dir === "in" ? spring(260, 24) : spring(280, 25);
  const anim = el.animate(o.dir === "in" ? [smallF, bigF] : [bigF, smallF], {
    duration: reduced() ? 1 : sp.duration,
    easing: sp.easing,
    fill: "both",
  });
  return {
    done: anim.finished.then(
      () => undefined,
      () => undefined,
    ),
    remove: () => el.remove(),
    cancel: () => {
      anim.cancel();
      el.remove();
    },
  };
}

/** A plain (text-free) surface that glides between two rects, e.g. the search field. */
export function ghostFly(o: { from: Rect; to: Rect; className: string; radius: number }): Flight {
  const { from, to } = o;
  const el = document.createElement("div");
  el.className = o.className;
  Object.assign(el.style, {
    position: "fixed",
    left: `${to.x}px`,
    top: `${to.y}px`,
    width: `${to.w}px`,
    height: `${to.h}px`,
    borderRadius: `${o.radius}px`,
    transformOrigin: "0 0",
    zIndex: "10000",
    pointerEvents: "none",
  });
  document.body.appendChild(el);
  const sp = spring(300, 30);
  const anim = el.animate(
    [
      {
        transform: `translate(${from.x - to.x}px, ${from.y - to.y}px) scale(${from.w / to.w}, ${from.h / to.h})`,
      },
      { transform: "translate(0px, 0px) scale(1, 1)" },
    ],
    { duration: reduced() ? 1 : sp.duration, easing: sp.easing, fill: "both" },
  );
  return {
    done: anim.finished.then(
      () => undefined,
      () => undefined,
    ),
    remove: () => el.remove(),
    cancel: () => {
      anim.cancel();
      el.remove();
    },
  };
}

/* ───────────── hiding the origin card while its photo is "in the air" ───── */

export function findCard(id: string, depth: "0" | "1"): HTMLElement | null {
  const safe = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(id) : id.replace(/"/g, '\\"');
  return document.querySelector<HTMLElement>(
    `.screen[data-depth="${depth}"] [data-card-id="${safe}"]`,
  );
}

export function holdCard(el: HTMLElement, mode: "busy" | "held") {
  el.style.visibility = "hidden";
  el.dataset.flightHidden = mode;
}

export function releaseCard(el: HTMLElement) {
  el.style.visibility = "";
  delete el.dataset.flightHidden;
}

/** Un-hide cards left hidden by a finished zoom-in once their screen is on top again. */
export function releaseStale(root: ParentNode) {
  root
    .querySelectorAll<HTMLElement>('[data-flight-hidden="held"]')
    .forEach((el) => releaseCard(el));
}

/* ───────────── small DOM writers (kept out of components on purpose) ───── */

export function setScrollTop(el: HTMLElement, y: number) {
  el.scrollTop = y;
}

export function lockScroll(el: HTMLElement, locked: boolean) {
  el.style.overflowY = locked ? "hidden" : "";
}
