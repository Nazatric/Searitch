import sharp from "sharp";

/* ─────────────── content-based image similarity (server side) ─────────────
   Two cheap, real signals per image:
   • dHash  — 64-bit difference hash of a 9×8 grayscale downsample. Similar
              images differ in only a few bits.
   • palette — an 8-bin RGB histogram of an 8×8 downsample, i.e. the image's
              dominant colour distribution.

   Comparing these makes "similar images" mean *visually* similar — same
   composition and colours — instead of merely sharing words in a filename.  */

export type Signature = {
  hash: Uint8Array; // 64 bits packed into 8 bytes
  palette: Float32Array; // 8 normalized bins
};

const cache = new Map<string, Signature | null>();
const MAX_CACHE = 400;

/** We only need a 9×8 sample, so fetch the smallest rendition available. */
function smallestRendition(url: string): string {
  return url
    .replace(/_[zcb]\.(jpg|png|gif)$/i, "_m.$1") // Flickr 640/800/1024 → 240
    .replace("th.wallhaven.cc/lg/", "th.wallhaven.cc/small/")
    .replace("th.wallhaven.cc/orig/", "th.wallhaven.cc/small/");
}

async function fetchBytes(url: string, ms = 5000): Promise<Buffer | null> {
  try {
    const res = await fetch(smallestRendition(url), {
      headers: { "User-Agent": "Searitch/1.0 (image similarity)" },
      signal: AbortSignal.timeout(ms),
    });
    if (!res.ok) return null;
    return Buffer.from(await res.arrayBuffer());
  } catch {
    return null;
  }
}

export async function signatureOf(url: string): Promise<Signature | null> {
  if (cache.has(url)) return cache.get(url) ?? null;

  const bytes = await fetchBytes(url);
  let sig: Signature | null = null;
  if (bytes && bytes.length > 0) {
    try {
      // One decode feeds both signals.
      const gray = await sharp(bytes)
        .resize(9, 8, { fit: "fill" })
        .grayscale()
        .raw()
        .toBuffer();
      const { data: rgb, info } = await sharp(bytes)
        .resize(8, 8, { fit: "fill" })
        .removeAlpha()
        .toColourspace("srgb")
        .raw()
        .toBuffer({ resolveWithObject: true });
      const ch = info.channels || 3;

      const hash = new Uint8Array(8);
      let bit = 0;
      for (let y = 0; y < 8; y++) {
        for (let x = 0; x < 8; x++) {
          const left = gray[y * 9 + x];
          const right = gray[y * 9 + x + 1];
          if (left > right) hash[bit >> 3] |= 1 << (bit & 7);
          bit++;
        }
      }

      const palette = new Float32Array(8);
      for (let i = 0; i < 64; i++) {
        const r = rgb[i * ch];
        const g = ch > 1 ? rgb[i * ch + 1] : r;
        const b = ch > 2 ? rgb[i * ch + 2] : r;
        // 2×2×2 colour cube bins
        palette[((r >> 7) << 2) | ((g >> 7) << 1) | (b >> 7)] += 1;
      }
      for (let i = 0; i < 8; i++) palette[i] /= 64;

      sig = { hash, palette };
    } catch {
      sig = null;
    }
  }

  if (cache.size > MAX_CACHE) cache.clear();
  cache.set(url, sig);
  return sig;
}

function hamming(a: Uint8Array, b: Uint8Array): number {
  let diff = 0;
  for (let i = 0; i < 8; i++) {
    let x = a[i] ^ b[i];
    while (x) {
      diff += x & 1;
      x >>= 1;
    }
  }
  return diff; // 0..64
}

function paletteDistance(a: Float32Array, b: Float32Array): number {
  let sum = 0;
  for (let i = 0; i < 8; i++) sum += Math.abs(a[i] - b[i]);
  return sum / 2; // 0..1
}

/** 0 (unrelated) → 1 (near identical). */
export function similarity(a: Signature | null, b: Signature | null): number {
  if (!a || !b) return 0;
  const structure = 1 - hamming(a.hash, b.hash) / 64;
  const colour = 1 - paletteDistance(a.palette, b.palette);
  return structure * 0.62 + colour * 0.38;
}

/** Jaccard overlap of semantic tags (real provider metadata, not guesses). */
export function tagOverlap(a: string[], b: string[]): number {
  if (a.length === 0 || b.length === 0) return 0;
  const setA = new Set(a.map((t) => t.toLowerCase()));
  let hits = 0;
  for (const t of b) if (setA.has(t.toLowerCase())) hits++;
  return hits / new Set([...setA, ...b.map((t) => t.toLowerCase())]).size;
}
