// Tiny profiling hook: marks are recorded only when a test/devtools session sets
// `window.__perf = true`, so production users pay nothing.
declare global {
  interface Window {
    __perf?: boolean;
  }
}

export function mark(name: string) {
  if (typeof window !== "undefined" && window.__perf) performance.mark(name);
}
