"use client";

import { useCallback, useSyncExternalStore } from "react";
import type { Img } from "@/lib/model";

/* ───────────────────────── streaming search jobs ─────────────────────────
   A search is a *job*: it starts the moment it is requested (even while the
   user is still typing), streams results in per source as each one answers
   (the first cards usually land in well under a second), and stays cached so
   coming back to a search is instant. Screens subscribe to jobs; they never
   own the network request.                                                  */

export type Job = {
  key: string;
  results: Img[];
  done: boolean;
  error: string | null;
  version: number;
  subs: Set<() => void>;
  seen: Set<string>;
};

const MAX_JOBS = 48;
const jobs = new Map<string, Job>();

function notify(j: Job) {
  j.version++;
  j.subs.forEach((fn) => fn());
}

/** Cards before this index are (probably) on screen and are never reordered. */
const HEAD = 10;

/** Spread `b` evenly through `a` (keeps a's order and b's order). */
function spread(a: Img[], b: Img[]): Img[] {
  const total = a.length + b.length;
  const out = new Array<Img>(total);
  const used = new Array<boolean>(total).fill(false);
  b.forEach((img, j) => {
    let p = Math.min(total - 1, Math.floor(((j + 0.5) * total) / b.length));
    while (p < total && used[p]) p++;
    if (p >= total) p = used.lastIndexOf(false);
    out[p] = img;
    used[p] = true;
  });
  let ai = 0;
  for (let k = 0; k < total; k++) if (!used[k]) out[k] = a[ai++];
  return out;
}

function add(job: Job, list: Img[], provider?: string) {
  const fresh = list.filter((i) => i.full && !job.seen.has(i.full));
  if (fresh.length === 0) return;
  fresh.forEach((i) => job.seen.add(i.full));
  const late = provider && provider !== "first" && provider !== "cache" && job.results.length > HEAD;
  job.results = late
    ? [...job.results.slice(0, HEAD), ...spread(job.results.slice(HEAD), fresh)]
    : [...job.results, ...fresh];
  notify(job);
}

function handle(job: Job, line: string) {
  try {
    const m = JSON.parse(line) as { r?: Img[]; p?: string };
    if (Array.isArray(m.r)) add(job, m.r, m.p);
  } catch {
    /* ignore a malformed line */
  }
}

async function run(job: Job) {
  try {
    const res = await fetch(`/api/search?${job.key}&stream=1`);
    if (!res.ok) {
      const d = (await res.json().catch(() => ({}))) as { error?: string };
      throw new Error(d.error ?? `Search failed (${res.status})`);
    }
    if (!res.body) {
      const d = (await res.json()) as { results?: Img[] };
      add(job, d.results ?? []);
      return;
    }
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = "";
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let nl: number;
      while ((nl = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, nl).trim();
        buf = buf.slice(nl + 1);
        if (line) handle(job, line);
      }
    }
    if (buf.trim()) handle(job, buf.trim());
  } catch (e) {
    job.error = e instanceof Error ? e.message : "Something went wrong.";
    // never keep a failed job: the next request must hit the network again
    if (jobs.get(job.key) === job) jobs.delete(job.key);
  } finally {
    job.done = true;
    notify(job);
  }
}

export function getJob(key: string): Job {
  const hit = jobs.get(key);
  if (hit) return hit;
  const job: Job = {
    key,
    results: [],
    done: false,
    error: null,
    version: 0,
    subs: new Set(),
    seen: new Set(),
  };
  if (jobs.size >= MAX_JOBS) {
    const first = jobs.keys().next().value;
    if (first !== undefined) jobs.delete(first);
  }
  jobs.set(key, job);
  void run(job);
  return job;
}

/** Re-run a search; screens already subscribed are moved to the fresh job. */
export function retryJob(key: string) {
  const old = jobs.get(key);
  jobs.delete(key);
  const fresh = getJob(key);
  if (old) {
    old.subs.forEach((cb) => fresh.subs.add(cb));
    old.subs.clear();
  }
  notify(fresh);
}

type Derived = {
  results: Img[];
  done: boolean;
  error: string | null;
  lastCount: number;
  lastDone: boolean;
};

const EMPTY: Derived = { results: [], done: false, error: null, lastCount: 0, lastDone: false };
const derivedCache = new Map<string, Derived>();

function derive(keys: string[]): Derived {
  const out: Img[] = [];
  const seen = new Set<string>();
  let done = true;
  let error: string | null = null;
  for (const k of keys) {
    const j = jobs.get(k);
    if (!j) {
      done = false;
      continue;
    }
    for (const im of j.results) {
      if (!seen.has(im.full)) {
        seen.add(im.full);
        out.push(im);
      }
    }
    if (!j.done) done = false;
    if (j.error) error = j.error;
  }
  const last = jobs.get(keys[keys.length - 1]);
  return { results: out, done, error, lastCount: last?.results.length ?? 0, lastDone: last?.done ?? false };
}

function snapshot(joined: string): Derived {
  const keys = joined.split("\n");
  const sig = keys
    .map((k) => {
      const j = jobs.get(k);
      return j ? `${j.version}${j.done ? "d" : ""}` : "x";
    })
    .join("|");
  const ck = `${joined}#${sig}`;
  let d = derivedCache.get(ck);
  if (!d) {
    d = derive(keys);
    derivedCache.set(ck, d);
    if (derivedCache.size > 160) {
      const first = derivedCache.keys().next().value;
      if (first !== undefined) derivedCache.delete(first);
    }
  }
  return d;
}

/** Subscribe to one or more page-jobs (starting them if needed). */
export function useJobs(keys: string[]): Derived {
  const joined = keys.join("\n");
  const subscribe = useCallback(
    (cb: () => void) => {
      const unsubs = joined.split("\n").map((k) => {
        const j = getJob(k);
        j.subs.add(cb);
        return () => {
          j.subs.delete(cb);
        };
      });
      return () => unsubs.forEach((u) => u());
    },
    [joined],
  );
  const get = useCallback(() => snapshot(joined), [joined]);
  return useSyncExternalStore(subscribe, get, () => EMPTY);
}

/* ───────────────────────────── search context ────────────────────────────
   The query the user is browsing gives "similar images" extra context.     */

let searchContext = "";
export function setSearchContext(q: string) {
  searchContext = q;
}
export function getSearchContext(): string {
  return searchContext;
}

/* ───────────────────────────── similar images ───────────────────────────── */

type RelatedEntry = { list?: Img[]; promise?: Promise<Img[]> };
const related = new Map<string, RelatedEntry>();

function boundRelated() {
  if (related.size > 40) {
    const first = related.keys().next().value;
    if (first !== undefined) related.delete(first);
  }
}

export function peekRelated(id: string): Img[] | undefined {
  return related.get(id)?.list;
}

/** Start (or reuse) the similar-images request. Warmed on pointer-down. */
export function warmRelated(img: Img): Promise<Img[]> {
  const hit = related.get(img.id);
  if (hit?.list) return Promise.resolve(hit.list);
  if (hit?.promise) return hit.promise;

  const url = `/api/related?${new URLSearchParams({
    id: img.id,
    title: img.title,
    tags: (img.tags ?? []).join(","),
    thumb: img.thumb,
    ctx: searchContext,
  })}`;
  const entry: RelatedEntry = {};
  entry.promise = fetch(url)
    .then((r) => (r.ok ? r.json() : { results: [] }))
    .then((d: { results?: Img[] }) => {
      const list = Array.isArray(d.results) ? d.results : [];
      if (list.length > 0) entry.list = list;
      else related.delete(img.id);
      entry.promise = undefined;
      return list;
    })
    .catch(() => {
      related.delete(img.id);
      return [] as Img[];
    });
  boundRelated();
  related.set(img.id, entry);
  return entry.promise;
}
