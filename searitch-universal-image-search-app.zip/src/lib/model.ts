// Pure data helpers shared by every screen (no React, no DOM).

export type Img = {
  id: string;
  provider: string;
  title: string;
  thumb: string;
  /** Lower-res thumbnail to fall back to if the sharp one 404s. */
  thumbFallback?: string;
  /** Sharper rendition, swapped in once the card is near the viewport. */
  thumbHi?: string;
  full: string;
  width: number;
  height: number;
  filetype: string;
  sourceSite: string;
  sourceUrl: string;
  creator?: string;
  license?: string;
  description?: string;
  /** Real semantic tags/categories from the source — powers smart similarity. */
  tags?: string[];
};

export type Filters = {
  type: "any" | "jpg" | "png" | "gif" | "svg" | "transparent";
  aspect: "any" | "tall" | "wide" | "square";
  size: "any" | "small" | "medium" | "large";
  color: string;
  license: "any" | "commercial" | "modification";
  provider:
    | "all"
    | "openverse"
    | "wikimedia"
    | "wallhaven"
    | "flickr"
    | "inaturalist"
    | "nasa"
    | "met"
    | "europeana"
    | "vam";
  safe: boolean;   // default: true (always enabled)
  antiAi: boolean; // default: true (filters out AI-generated content)
};

export const DEFAULT_FILTERS: Filters = {
  type: "any",
  aspect: "any",
  size: "any",
  color: "",
  license: "any",
  provider: "all",
  safe: true,
  antiAi: true,
};

export const COLORS: Array<{ key: string; label: string; css: string }> = [
  { key: "red", label: "Red", css: "#c0392b" },
  { key: "orange", label: "Orange", css: "#e67e22" },
  { key: "yellow", label: "Yellow", css: "#f1c40f" },
  { key: "green", label: "Green", css: "#27ae60" },
  { key: "teal", label: "Teal", css: "#16a085" },
  { key: "blue", label: "Blue", css: "#2980b9" },
  { key: "purple", label: "Purple", css: "#8e44ad" },
  { key: "pink", label: "Pink", css: "#e84393" },
  { key: "brown", label: "Brown", css: "#8d5a2b" },
  { key: "black", label: "Black", css: "#1b1b1b" },
  { key: "white", label: "White", css: "#f5f0e6" },
  { key: "gray", label: "Gray", css: "#95a5a6" },
];

export function parseFilters(sp: URLSearchParams): Filters {
  const g = (k: string) => sp.get(k) ?? "";
  const oneOf = <T extends string>(v: string, allowed: readonly T[], d: T): T =>
    (allowed as readonly string[]).includes(v) ? (v as T) : d;
  return {
    type: oneOf(g("type"), ["any", "jpg", "png", "gif", "svg", "transparent"] as const, "any"),
    aspect: oneOf(g("aspect"), ["any", "tall", "wide", "square"] as const, "any"),
    size: oneOf(g("size"), ["any", "small", "medium", "large"] as const, "any"),
    color: g("color").slice(0, 16),
    license: oneOf(g("license"), ["any", "commercial", "modification"] as const, "any"),
    provider: oneOf(
      g("provider"),
      [
        "all", "openverse", "wikimedia", "wallhaven", "flickr",
        "inaturalist", "nasa", "met", "europeana", "vam",
      ] as const,
      "all",
    ),
    safe: sp.get("safe") === "0" || sp.get("safe") === "false" ? false : true,
    antiAi:
      sp.get("antiAi") === "0" ||
      sp.get("antiAi") === "false" ||
      sp.get("noai") === "0"
        ? false
        : true,
  };
}

export function filtersToParams(q: string, f: Filters): URLSearchParams {
  const p = new URLSearchParams({ q });
  if (f.type !== "any") p.set("type", f.type);
  if (f.aspect !== "any") p.set("aspect", f.aspect);
  if (f.size !== "any") p.set("size", f.size);
  if (f.color) p.set("color", f.color);
  if (f.license !== "any") p.set("license", f.license);
  if (f.provider !== "all") p.set("provider", f.provider);
  if (!f.safe) p.set("safe", "0");
  if (!f.antiAi) p.set("antiAi", "0");
  return p;
}

/** Canonical cache key — identical on the warming side and the reading side. */
export function searchKey(q: string, f: Filters, page = 1): string {
  const p = filtersToParams(q, f);
  p.set("page", String(page));
  return p.toString();
}

export function activeFilterCount(f: Filters): number {
  let n = 0;
  if (f.type !== "any") n++;
  if (f.aspect !== "any") n++;
  if (f.size !== "any") n++;
  if (f.color) n++;
  if (f.license !== "any") n++;
  if (f.provider !== "all") n++;
  if (!f.safe) n++;
  if (!f.antiAi) n++;
  return n;
}

/** Encode a full image record into URL params (deep links / copy link). */
export function imgToParams(img: Img): URLSearchParams {
  const p = new URLSearchParams({
    id: img.id,
    t: img.title.slice(0, 160),
    th: img.thumb,
    f: img.full,
    w: String(img.width || 0),
    h: String(img.height || 0),
    ft: img.filetype,
    site: img.sourceSite,
    su: img.sourceUrl,
  });
  if (img.creator) p.set("cr", img.creator.slice(0, 120));
  if (img.license) p.set("li", img.license.slice(0, 60));
  if (img.tags?.length) p.set("tg", img.tags.slice(0, 8).join(","));
  return p;
}

export function paramsToImg(sp: URLSearchParams): Img | null {
  const full = sp.get("f") ?? "";
  if (!full) return null;
  return {
    id: sp.get("id") ?? "",
    provider: (sp.get("id") ?? "").split(":")[0] || "unknown",
    title: sp.get("t") || "Untitled",
    thumb: sp.get("th") || full,
    full,
    width: parseInt(sp.get("w") ?? "0", 10) || 0,
    height: parseInt(sp.get("h") ?? "0", 10) || 0,
    filetype: sp.get("ft") ?? "",
    sourceSite: sp.get("site") ?? "unknown",
    sourceUrl: sp.get("su") || full,
    creator: sp.get("cr") ?? undefined,
    license: sp.get("li") ?? undefined,
    tags: (sp.get("tg") ?? "").split(",").map((t) => t.trim()).filter(Boolean),
  };
}

/**
 * Reserved box ratio for a card's image. Known dimensions are clamped so
 * extreme panoramas can't wreck the grid; unknown ones (Flickr's public feed)
 * get 4:3 which the image fills with object-cover — so the layout NEVER shifts
 * when an image finishes loading.
 */
/** Caption on a print. Hide serial/generic names so the grid stays a book of photos. */
export function displayTitle(title: string): string | null {
  const t = title.trim();
  if (!t) return null;
  if (/^untitled$/i.test(t)) return null;
  if (/^wallpaper\s+\d+\s*[×x]\s*\d+$/i.test(t)) return null;
  if (/^image\s+\d+$/i.test(t)) return null;
  return t;
}

export function cardRatio(img: Img): number {
  if (img.width > 0 && img.height > 0) {
    return Math.min(Math.max(img.width / img.height, 0.62), 1.8);
  }
  return 4 / 3;
}

/** True aspect ratio of the picture itself (for the detail view). */
export function trueRatio(img: Img): number | null {
  return img.width > 0 && img.height > 0 ? img.width / img.height : null;
}
