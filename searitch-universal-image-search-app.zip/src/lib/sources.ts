// ─────────────────────────────────────────────────────────────────────────────
// Searitch · direct source providers
//
// Openverse indexes 52 sites. We query the fast public APIs directly where
// possible: Flickr, Wikimedia, Wallhaven, iNaturalist, NASA, The Met, V&A and
// Europeana. Every item is a live source result, never synthetic content.
//
// Openverse's own /images endpoint is often very slow (its backend fans out to
// all 52 sites), so we query the underlying APIs DIRECTLY, in parallel, and
// merge the results. Every provider below is keyless and returns real,
// licensed media.
//
// Each provider is best-effort: a failure never blocks the others.
// ─────────────────────────────────────────────────────────────────────────────

export type SourceImage = {
  id: string;
  provider: string;
  title: string;
  thumb: string;
  thumbFallback?: string;
  full: string;
  width: number;
  height: number;
  filetype: string;
  sourceSite: string;
  sourceUrl: string;
  creator?: string;
  license?: string;
  description?: string;
  tags: string[];
};

const UA = "Searitch/1.0 (universal image search; +https://searitch.app)";
const TIMEOUT = 6000;

function extOf(url: string): string {
  const m = url.split("?")[0].match(/\.([a-z0-9]{2,5})$/i);
  const e = m ? m[1].toLowerCase() : "";
  return e === "jpeg" ? "jpg" : e;
}

function stripTags(html?: string): string {
  return html ? html.replace(/<[^>]*>/g, "").trim() : "";
}

async function getJson(url: string, ms = TIMEOUT): Promise<unknown | null> {
  try {
    const res = await fetch(url, {
      headers: { "User-Agent": UA, Accept: "application/json" },
      signal: AbortSignal.timeout(ms),
      cache: "no-store",
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

/* ═══════════════════════════════════════════════════════════════════════════
   iNaturalist — 266 million observations (CC-licensed nature photography)
   ═══════════════════════════════════════════════════════════════════════════ */

export async function searchINaturalist(q: string): Promise<SourceImage[]> {
  const url =
    `https://api.inaturalist.org/v1/observations?taxa=${encodeURIComponent(q)}` +
    `&photos=true&photo_license=cc0,cc-by,cc-by-sa&per_page=24&order_by=votes`;
  const json = (await getJson(url)) as {
    results?: Array<{
      id: number;
      taxon?: { name?: string; preferred_common_name?: string };
      photos?: Array<{ url: string; attribution?: string | null }>;
    }>;
  } | null;
  if (!json?.results) return [];

  const out: SourceImage[] = [];
  for (const r of json.results) {
    const photo = r.photos?.[0];
    if (!photo?.url) continue;
    const full = photo.url.replace("/square.", "/original.");
    const name = r.taxon?.preferred_common_name || r.taxon?.name || "Untitled";
    out.push({
      id: `inat:${r.id}`,
      provider: "inaturalist",
      title: name,
      thumb: photo.url,
      thumbFallback: photo.url,
      full,
      width: 0,
      height: 0,
      filetype: "jpg",
      sourceSite: "iNaturalist",
      sourceUrl: `https://www.inaturalist.org/observations/${r.id}`,
      creator: stripTags(photo.attribution ?? undefined) || undefined,
      license: "CC",
      tags: [name.toLowerCase(), "nature"].filter(Boolean),
    });
  }
  return out;
}

/* ═══════════════════════════════════════════════════════════════════════════
   Europeana — 14 million cultural-heritage objects
   ═══════════════════════════════════════════════════════════════════════════ */

export async function searchEuropeana(q: string): Promise<SourceImage[]> {
  // Europeana's public demo key is rate-limited but works without user setup.
  // The v2 record search returns actual preview JPEG URLs and rights metadata.
  const url =
    `https://api.europeana.eu/record/v2/search.json?wskey=api2demo` +
    `&query=${encodeURIComponent(q)}&rows=24&media=true&reusability=open&profile=portal`;
  const json = (await getJson(url)) as {
    items?: Array<{
      id?: string;
      title?: string[];
      edmIsShownBy?: string[];
      edmPreview?: string[];
      dcCreator?: string;
      dcDescription?: string[];
      rights?: string[];
      guid?: string;
    }>;
  } | null;
  if (!json?.items) return [];

  const out: SourceImage[] = [];
  for (const it of json.items) {
    const full = it.edmIsShownBy?.[0] || it.edmPreview?.[0];
    if (!full) continue;
    const thumb = it.edmPreview?.[0] || full;
    out.push({
      id: `europeana:${it.id ?? it.guid ?? full}`,
      provider: "europeana",
      title: (it.title?.[0] ?? "Untitled").toString(),
      thumb,
      full,
      width: 0,
      height: 0,
      filetype: extOf(full) || "jpg",
      sourceSite: "Europeana",
      sourceUrl: it.guid ?? `https://www.europeana.eu/en/item/${it.id}`,
      creator: it.dcCreator,
      description: it.dcDescription?.join(" ").slice(0, 3000),
      license: it.rights?.[0],
      tags: ["heritage", "culture"],
    });
  }
  return out;
}

/* ═══════════════════════════════════════════════════════════════════════════
   The Metropolitan Museum of Art — 498k public-domain works
   ═══════════════════════════════════════════════════════════════════════════ */

export async function searchMet(q: string): Promise<SourceImage[]> {
  // The search endpoint moved to v1.1 (Elastic-backed); object records are
  // still served by v1. A "fox" search matches thousands of objects.
  const ids = (await getJson(
    `https://collectionapi.metmuseum.org/public/collection/v1.1/search?hasImages=true&q=${encodeURIComponent(q)}`,
    5000,
  )) as { objectIDs?: number[] } | null;
  const first = (ids?.objectIDs ?? []).slice(0, 10);
  if (first.length === 0) return [];

  const objects = await Promise.all(
    first.map((id) =>
      getJson(
        `https://collectionapi.metmuseum.org/public/collection/v1/objects/${id}`,
        5000,
      ),
    ),
  );

  const out: SourceImage[] = [];
  for (const o of objects) {
    const obj = o as {
      objectID?: number;
      title?: string;
      artistDisplayName?: string;
      primaryImage?: string;
      primaryImageSmall?: string;
      isPublicDomain?: boolean;
      objectURL?: string;
      tags?: Array<{ term?: string }>;
    } | null;
    if (!obj?.primaryImage) continue;
    out.push({
      id: `met:${obj.objectID}`,
      provider: "met",
      title: obj.title ?? "Untitled",
      thumb: obj.primaryImageSmall ?? obj.primaryImage,
      full: obj.primaryImage,
      width: 0,
      height: 0,
      filetype: "jpg",
      sourceSite: "The Met",
      sourceUrl: obj.objectURL ?? "https://www.metmuseum.org/art/collection",
      creator: obj.artistDisplayName,
      license: obj.isPublicDomain ? "Public Domain" : undefined,
      tags: (obj.tags ?? []).map((t) => t.term ?? "").filter(Boolean).slice(0, 6),
    });
  }
  return out;
}

/* ═══════════════════════════════════════════════════════════════════════════
   NASA Image and Video Library — 132k images, public domain
   ═══════════════════════════════════════════════════════════════════════════ */

export async function searchNasa(q: string): Promise<SourceImage[]> {
  const json = (await getJson(
    `https://images-api.nasa.gov/search?q=${encodeURIComponent(q)}&media_type=image&page_size=24`,
  )) as {
    collection?: {
      items?: Array<{
        href?: string;
        data?: Array<{
          nasa_id?: string;
          title?: string;
          center?: string;
          description?: string;
          keywords?: string[];
        }>;
        links?: Array<{ href?: string; rel?: string }>;
      }>;
    };
  } | null;
  const items = json?.collection?.items ?? [];
  if (items.length === 0) return [];

  const out: SourceImage[] = [];
  for (const it of items) {
    const d = it.data?.[0];
    const img = it.links?.find((l) => l.rel === "preview")?.href ?? it.links?.[0]?.href;
    if (!d || !img) continue;
    out.push({
      id: `nasa:${d.nasa_id ?? img}`,
      provider: "nasa",
      title: d.title ?? "Untitled",
      thumb: img,
      full: img,
      width: 0,
      height: 0,
      filetype: "jpg",
      sourceSite: "NASA",
      sourceUrl: `https://images.nasa.gov/details/${d.nasa_id ?? ""}`,
      creator: d.center,
      description: d.description?.slice(0, 3000),
      license: "Public Domain",
      tags: (d.keywords ?? []).slice(0, 6),
    });
  }
  return out;
}

/* ═══════════════════════════════════════════════════════════════════════════
   Victoria and Albert Museum — 2.5M objects (keyless, real image CDN)
   ═══════════════════════════════════════════════════════════════════════════ */

export async function searchVam(q: string): Promise<SourceImage[]> {
  const json = (await getJson(
    `https://api.vam.ac.uk/v2/objects/search?q=${encodeURIComponent(q)}&page_size=24&images_exist=1`,
  )) as {
    records?: Array<{
      systemNumber?: string;
      accessionNumber?: string;
      objectType?: string;
      _primaryTitle?: string;
      _primaryMaker?: { name?: string };
      _primaryDate?: string;
      _images?: { _primary_thumbnail?: string; _primary?: string };
    }>;
  } | null;
  if (!json?.records) return [];

  const out: SourceImage[] = [];
  for (const r of json.records) {
    const thumb = r._images?._primary_thumbnail;
    const full = r._images?._primary;
    if (!thumb) continue;
    out.push({
      id: `vam:${r.systemNumber ?? r.accessionNumber ?? thumb}`,
      provider: "vam",
      title: r._primaryTitle ?? "Untitled",
      // The thumbnail path ends in "!100,100" — swap in a larger rendition.
      thumb: thumb.replace("/!100,100/", "/!400,400/"),
      thumbFallback: thumb,
      full: full ?? thumb,
      width: 0,
      height: 0,
      filetype: "jpg",
      sourceSite: "V&A Museum",
      sourceUrl: `https://collections.vam.ac.uk/item/${r.systemNumber ?? ""}`,
      creator: r._primaryMaker?.name,
      license: "CC0",
      tags: (r.objectType ?? "museum")
        .toLowerCase()
        .split(/[,;]/)
        .map((t) => t.trim())
        .filter(Boolean),
    });
  }
  return out;
}

/* ═══════════════════════════════════════════════════════════════════════════
   The provider registry. Each entry is queried in parallel; a slow or broken
   one is skipped without holding up the rest.
   ═══════════════════════════════════════════════════════════════════════════ */

export type SourceProvider = {
  key: string;
  label: string;
  run: (q: string) => Promise<SourceImage[]>;
};

export const SOURCE_PROVIDERS: SourceProvider[] = [
  { key: "inaturalist", label: "iNaturalist", run: searchINaturalist },
  { key: "europeana", label: "Europeana", run: searchEuropeana },
  { key: "nasa", label: "NASA", run: searchNasa },
  { key: "met", label: "The Met", run: searchMet },
  { key: "vam", label: "V&A Museum", run: searchVam },
];

/** All provider labels, for the "Source" filter UI. */
export const SOURCE_LABELS = [
  "All sources",
  "Flickr",
  "Wikimedia Commons",
  "Wallhaven",
  "iNaturalist",
  "NASA",
  "The Met",
  "Europeana",
  "V&A Museum",
] as const;

/** Map a UI label to a provider key (used by the Source filter). */
export const LABEL_TO_KEY: Record<string, string> = {
  Flickr: "flickr",
  "Wikimedia Commons": "wikimedia",
  Wallhaven: "wallhaven",
  iNaturalist: "inaturalist",
  NASA: "nasa",
  "The Met": "met",
  Europeana: "europeana",
  "V&A Museum": "vam",
};
