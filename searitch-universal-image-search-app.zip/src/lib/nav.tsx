"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
  type ReactNode,
  type RefObject,
} from "react";
import {
  DEFAULT_FILTERS,
  filtersToParams,
  imgToParams,
  paramsToImg,
  parseFilters,
  type Filters,
  type Img,
} from "@/lib/model";
import type { Rect } from "@/lib/flight";
import { mark } from "@/lib/perf";

/* ───────────────────────── screen stack (the native model) ────────────────
   Exactly like a Compose back-stack: Home → Search → Detail → Detail …
   Every screen change is a synchronous state update in the SAME frame as the
   tap — there is no route fetch, so there is nothing to wait for. The browser
   history is kept in sync (pushState/popstate) so Back, the Android back
   gesture and shareable URLs all keep working.                              */

export type Origin =
  | {
      kind: "card";
      id: string;
      rect: Rect;
      src: string;
      nat: { w: number; h: number };
      radius: number;
    }
  | { kind: "field"; rect: Rect };

export type Screen =
  | { kind: "home" }
  | { kind: "search"; q: string; filters: Filters }
  | { kind: "detail"; img: Img };

export type Anim = "none" | "fade" | "zoom" | "rise";

export type Entry = { id: number; screen: Screen; origin?: Origin; anim: Anim };

export type Layer = { key: number; entry: Entry; depth: number; leaving: boolean };

type View = {
  trail: Entry[];
  pos: number;
  leaving: Array<{ key: number; entry: Entry }>;
};

type Initial = "home" | "search" | "detail";

const HOME: Screen = { kind: "home" };

export function urlFor(s: Screen): string {
  if (s.kind === "search") return `/search?${filtersToParams(s.q, s.filters)}`;
  if (s.kind === "detail") return `/image?${imgToParams(s.img)}`;
  return "/";
}

function parseLocation(): Screen {
  const { pathname, search } = window.location;
  const sp = new URLSearchParams(search);
  if (pathname.startsWith("/search")) {
    const q = (sp.get("q") ?? "").trim();
    if (q) return { kind: "search", q, filters: parseFilters(sp) };
  }
  if (pathname.startsWith("/image")) {
    const img = paramsToImg(sp);
    if (img) return { kind: "detail", img };
  }
  return HOME;
}

function serverView(initial: Initial): View {
  return initial === "home"
    ? { trail: [{ id: 0, screen: HOME, anim: "none" }], pos: 0, leaving: [] }
    : { trail: [], pos: -1, leaving: [] };
}

function locationView(initial: Initial): View {
  if (typeof window === "undefined") return serverView(initial);
  return { trail: [{ id: 0, screen: parseLocation(), anim: "none" }], pos: 0, leaving: [] };
}

function sameScreen(a: Screen, b: Screen): boolean {
  if (a.kind !== b.kind) return false;
  if (a.kind === "search" && b.kind === "search") {
    return filtersToParams(a.q, a.filters).toString() === filtersToParams(b.q, b.filters).toString();
  }
  if (a.kind === "detail" && b.kind === "detail") return a.img.id === b.img.id;
  return true;
}

function pickAnim(from: Screen | undefined, to: Screen, origin?: Origin): Anim {
  if (to.kind === "detail") return origin?.kind === "card" ? "zoom" : "fade";
  if (to.kind === "search") {
    if (from?.kind === "search") return "none";
    return from?.kind === "home" ? "rise" : "fade";
  }
  return "fade";
}

/**
 * Layers = visible screens. Consecutive Search entries (a new query, a filter
 * change) share ONE layer so the screen doesn't re-mount — only its props change.
 */
export function buildLayers(v: View): Layer[] {
  const stack = v.trail.slice(0, v.pos + 1);
  const runs: Array<{ key: number; entry: Entry }> = [];
  stack.forEach((e, i) => {
    const prev = stack[i - 1];
    if (e.screen.kind === "search" && prev?.screen.kind === "search") {
      runs[runs.length - 1] = { key: runs[runs.length - 1].key, entry: e };
    } else {
      runs.push({ key: e.id, entry: e });
    }
  });
  const n = runs.length;
  const layers: Layer[] = runs.map((r, i) => ({
    key: r.key,
    entry: r.entry,
    depth: n - 1 - i,
    leaving: false,
  }));
  v.leaving.forEach((l) => layers.push({ key: l.key, entry: l.entry, depth: -1, leaving: true }));
  return layers;
}

function popView(v: View, newPos: number): View {
  if (newPos > v.pos) {
    // Forward button: entries come back without a stale zoom origin.
    const trail = v.trail.map((e, i) =>
      i > v.pos && i <= newPos ? { ...e, origin: undefined, anim: "fade" as Anim } : e,
    );
    return { ...v, trail, pos: newPos };
  }
  if (newPos === v.pos) return v;
  const before = buildLayers({ ...v, leaving: [] });
  const after = buildLayers({ ...v, pos: newPos, leaving: [] });
  const keep = new Set(after.map((l) => l.key));
  const gone = before.filter((l) => !keep.has(l.key));
  const top = gone[gone.length - 1];
  return {
    trail: v.trail,
    pos: newPos,
    leaving: top ? [...v.leaving, { key: top.key, entry: top.entry }] : v.leaving,
  };
}

/** Scroll position per layer — survives a layer being unmounted far below the top. */
export const scrollMemory = new Map<number, number>();

type Actions = {
  push: (screen: Screen, origin?: Origin) => void;
  openImage: (img: Img, origin?: Origin) => void;
  search: (q: string, filters: Filters, origin?: Origin) => void;
  back: () => void;
  finishLeaving: (key: number) => void;
  /** An entry's one-shot enter flight has started; never replay it on re-mount. */
  consume: (entryId: number) => void;
};

const ActionsCtx = createContext<Actions | null>(null);
const LayersCtx = createContext<Layer[]>([]);
export const ScrollerCtx = createContext<RefObject<HTMLDivElement | null> | null>(null);

export function useNavActions(): Actions {
  const a = useContext(ActionsCtx);
  if (!a) throw new Error("useNavActions outside NavProvider");
  return a;
}
export function useLayers(): Layer[] {
  return useContext(LayersCtx);
}
export function useScroller(): RefObject<HTMLDivElement | null> {
  const s = useContext(ScrollerCtx);
  if (!s) throw new Error("useScroller outside a screen layer");
  return s;
}

const noopSubscribe = () => () => undefined;

export function NavProvider({ initial, children }: { initial: Initial; children: ReactNode }) {
  const hydrated = useSyncExternalStore(
    noopSubscribe,
    () => true,
    () => false,
  );
  const [view, setView] = useState<View | null>(null);
  const base = useMemo(
    () => (hydrated ? locationView(initial) : serverView(initial)),
    [hydrated, initial],
  );
  const current = view ?? base;

  const viewRef = useRef<View>(current);
  useEffect(() => {
    viewRef.current = current;
  });

  const idRef = useRef(1);
  const pendingPop = useRef(0);
  const lastPush = useRef(0);

  const commit = useCallback((v: View) => {
    viewRef.current = v;
    setView(v);
  }, []);

  // Tag the first history entry so popstate can recognise it later.
  useEffect(() => {
    const st = window.history.state as { sid?: number } | null;
    if (st?.sid === undefined) {
      window.history.replaceState(
        { sid: viewRef.current.trail[0]?.id ?? 0, idx: 0 },
        "",
        window.location.href,
      );
    }
  }, []);

  useEffect(() => {
    const onPop = (e: PopStateEvent) => {
      // Our own back() already updated the view synchronously.
      if (pendingPop.current > 0) {
        pendingPop.current -= 1;
        return;
      }
      const v = viewRef.current;
      const st = e.state as { sid?: number; idx?: number } | null;
      if (st && typeof st.idx === "number" && v.trail[st.idx]?.id === st.sid) {
        commit(popView(v, st.idx));
      } else {
        // Unknown entry (reload / external navigation): rebuild from the URL.
        const entry: Entry = { id: idRef.current++, screen: parseLocation(), anim: "none" };
        window.history.replaceState({ sid: entry.id, idx: 0 }, "", window.location.href);
        commit({ trail: [entry], pos: 0, leaving: [] });
      }
    };
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, [commit]);

  const push = useCallback(
    (screen: Screen, origin?: Origin) => {
      const v = viewRef.current;
      const now = performance.now();
      if (now - lastPush.current < 260) return; // ignore double-taps mid-transition
      const top = v.trail[v.pos];
      if (top && sameScreen(top.screen, screen)) return;
      lastPush.current = now;
      mark("push:start");
      const entry: Entry = {
        id: idRef.current++,
        screen,
        origin,
        anim: pickAnim(top?.screen, screen, origin),
      };
      const trail = [...v.trail.slice(0, v.pos + 1), entry];
      mark("push:beforePushState");
      window.history.pushState({ sid: entry.id, idx: trail.length - 1 }, "", urlFor(screen));
      mark("push:afterPushState");
      commit({ trail, pos: trail.length - 1, leaving: v.leaving });
      mark("push:afterCommit");
    },
    [commit],
  );

  const back = useCallback(() => {
    const v = viewRef.current;
    if (v.pos > 0) {
      pendingPop.current += 1;
      window.history.back();
      commit(popView(v, v.pos - 1));
      return;
    }
    // Deep-linked first screen: "back" means Home.
    const top = v.trail[v.pos];
    if (top && top.screen.kind !== "home") {
      const entry: Entry = { id: idRef.current++, screen: HOME, anim: "none" };
      window.history.replaceState({ sid: entry.id, idx: 0 }, "", "/");
      const topLayer = buildLayers({ ...v, leaving: [] }).pop();
      commit({
        trail: [entry],
        pos: 0,
        leaving: topLayer ? [...v.leaving, { key: topLayer.key, entry: top }] : v.leaving,
      });
    }
  }, [commit]);

  const finishLeaving = useCallback(
    (key: number) => {
      const v = viewRef.current;
      if (!v.leaving.some((l) => l.key === key)) return;
      commit({ ...v, leaving: v.leaving.filter((l) => l.key !== key) });
    },
    [commit],
  );

  const consume = useCallback((entryId: number) => {
    const e = viewRef.current.trail.find((t) => t.id === entryId);
    if (e) {
      e.origin = undefined;
      e.anim = "none";
    }
  }, []);

  const actions = useMemo<Actions>(
    () => ({
      push,
      openImage: (img, origin) => push({ kind: "detail", img }, origin),
      search: (q, filters, origin) => push({ kind: "search", q, filters }, origin),
      back,
      finishLeaving,
      consume,
    }),
    [push, back, finishLeaving, consume],
  );

  const layers = useMemo(() => buildLayers(current), [current]);

  return (
    <ActionsCtx.Provider value={actions}>
      <LayersCtx.Provider value={layers}>{children}</LayersCtx.Provider>
    </ActionsCtx.Provider>
  );
}

export { DEFAULT_FILTERS };
