// Inline SVG icons: crisp at any density and identical on every device —
// no dependence on which system font happens to contain a glyph.
type P = { className?: string };

const base = {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2.4,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": true,
} as const;

export const IconSearch = ({ className = "h-5 w-5" }: P) => (
  <svg {...base} className={className}>
    <circle cx="11" cy="11" r="6.5" />
    <path d="m16 16 4.5 4.5" />
  </svg>
);

export const IconBack = ({ className = "h-6 w-6" }: P) => (
  <svg {...base} className={className}>
    <path d="m14.5 5-7 7 7 7" />
  </svg>
);

export const IconFilter = ({ className = "h-5 w-5" }: P) => (
  <svg {...base} className={className}>
    <path d="M4 7h10M18 7h2M4 17h2M10 17h10" />
    <circle cx="16" cy="7" r="2" />
    <circle cx="8" cy="17" r="2" />
  </svg>
);

export const IconClose = ({ className = "h-4 w-4" }: P) => (
  <svg {...base} className={className}>
    <path d="M6 6l12 12M18 6 6 18" />
  </svg>
);

export const IconLink = ({ className = "h-5 w-5" }: P) => (
  <svg {...base} className={className}>
    <path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1" />
    <path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1" />
  </svg>
);

export const IconDownload = ({ className = "h-4 w-4" }: P) => (
  <svg {...base} className={className}>
    <path d="M12 4v11" />
    <path d="m7 11 5 5 5-5" />
    <path d="M5 20h14" />
  </svg>
);

export const IconExternal = ({ className = "h-4 w-4" }: P) => (
  <svg {...base} className={className}>
    <path d="M14 5h5v5" />
    <path d="M19 5 11 13" />
    <path d="M18 14v4a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h4" />
  </svg>
);

export const IconHistory = ({ className = "h-4 w-4" }: P) => (
  <svg {...base} className={className}>
    <path d="M4 12a8 8 0 1 0 2.5-5.8" />
    <path d="M4 4v4h4" />
    <path d="M12 8v4l3 2" />
  </svg>
);

export const IconUp = ({ className = "h-5 w-5" }: P) => (
  <svg {...base} className={className}>
    <path d="M12 19V6" />
    <path d="m6 11 6-6 6 6" />
  </svg>
);

export const IconCheck = ({ className = "h-4 w-4" }: P) => (
  <svg {...base} className={className}>
    <path d="m5 12.5 4.5 4.5L19 7.5" />
  </svg>
);

export const IconShield = ({ className = "h-4 w-4" }: P) => (
  <svg {...base} className={className}>
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
  </svg>
);

export const IconSparkles = ({ className = "h-4 w-4" }: P) => (
  <svg {...base} className={className}>
    <path d="m12 3 1.9 4.8L19 9.5l-4.2 3.4 1.3 5.1-4.1-3-4.1 3 1.3-5.1L5 9.5l5.1-1.7L12 3z" />
  </svg>
);
