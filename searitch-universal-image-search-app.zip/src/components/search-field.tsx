"use client";

import {
  useEffect,
  useId,
  useRef,
  useState,
  type FormEvent,
  type KeyboardEvent,
} from "react";
import { IconClose, IconFilter, IconHistory, IconSearch } from "@/components/icons";

/* The dropdown shows YOUR recent searches only, stored on this device
   (localStorage). Nothing is shared or sent anywhere.
   Keyboard: ↑/↓ highlight · Enter selects · Esc closes.                      */

const STORE_KEY = "searitch:recent";
const MAX_RECENT = 8;

function readRecents(): string[] {
  try {
    const raw = window.localStorage.getItem(STORE_KEY);
    const list = raw ? (JSON.parse(raw) as unknown) : [];
    return Array.isArray(list)
      ? list.filter((v): v is string => typeof v === "string").slice(0, MAX_RECENT)
      : [];
  } catch {
    return [];
  }
}

function writeRecents(list: string[]) {
  try {
    window.localStorage.setItem(STORE_KEY, JSON.stringify(list.slice(0, MAX_RECENT)));
  } catch {
    /* storage unavailable (private mode) — recents are optional */
  }
}

function saveRecent(q: string) {
  const key = q.toLowerCase();
  writeRecents([q, ...readRecents().filter((r) => r.toLowerCase() !== key)]);
}

function matchRecents(value: string): string[] {
  const v = value.trim().toLowerCase();
  const all = readRecents();
  const list = v ? all.filter((r) => r.toLowerCase().includes(v) && r.toLowerCase() !== v) : all;
  return list.slice(0, 6);
}

export default function SearchField({
  initialValue = "",
  onSearch,
  onPreview,
  onFilter,
  filterCount = 0,
  autoFocus = false,
  variant = "home",
}: {
  initialValue?: string;
  /** `field` is the field's element — screens use its rect for the glide animation. */
  onSearch: (q: string, field: HTMLElement | null) => void;
  /** Fired while typing so the parent can warm the search before Enter. */
  onPreview?: (q: string) => void;
  /** When set, a filter control is pinned inside the field (always tappable on portrait). */
  onFilter?: () => void;
  filterCount?: number;
  autoFocus?: boolean;
  variant?: "home" | "bar";
}) {
  const listId = useId();
  const [value, setValue] = useState(initialValue);
  const [items, setItems] = useState<string[]>([]);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(-1);
  const wrapRef = useRef<HTMLDivElement>(null);
  const fieldRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Desktop only: auto-focus on touch would pop the keyboard over the screen.
  useEffect(() => {
    if (autoFocus && window.matchMedia("(pointer: fine)").matches) inputRef.current?.focus();
  }, [autoFocus]);

  useEffect(() => {
    const onDown = (e: PointerEvent) => {
      if (!wrapRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("pointerdown", onDown, { passive: true });
    return () => document.removeEventListener("pointerdown", onDown);
  }, []);

  const refresh = (v: string) => {
    const list = matchRecents(v);
    setItems(list);
    setOpen(list.length > 0);
    setActive(-1);
  };

  const submit = (q: string) => {
    const clean = q.trim();
    if (!clean) return;
    saveRecent(clean);
    setOpen(false);
    setActive(-1);
    inputRef.current?.blur();
    onSearch(clean, fieldRef.current);
  };

  const onKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (!open || items.length === 0) {
      if (e.key === "Enter") {
        e.preventDefault();
        submit(value);
      }
      return;
    }
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActive((a) => (a + 1) % items.length);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActive((a) => (a <= 0 ? items.length - 1 : a - 1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      submit(active >= 0 ? items[active] : value);
    } else if (e.key === "Escape") {
      setOpen(false);
    }
  };

  const isBar = variant === "bar";

  return (
    <div ref={wrapRef} className={isBar ? "relative min-w-0 flex-1" : "relative w-full"}>
      <form
        onSubmit={(e: FormEvent) => {
          e.preventDefault();
          submit(value);
        }}
        className="w-full min-w-0"
      >
        <div
          ref={fieldRef}
          data-field={variant}
          className={`field flex w-full min-w-0 items-center ${isBar ? "h-11 pl-3 pr-1.5" : "h-14 pl-4 pr-2"}`}
        >
          {!isBar && <IconSearch className="mr-2.5 h-5 w-5 shrink-0 text-[#7d6845]" />}
          <input
            ref={inputRef}
            value={value}
            onChange={(e) => {
              const v = e.target.value;
              setValue(v);
              refresh(v);
              if (v.trim().length >= 2) onPreview?.(v.trim());
            }}
            onFocus={() => refresh(value)}
            onKeyDown={onKeyDown}
            placeholder={isBar ? "Search images…" : "Search anything…"}
            enterKeyHint="search"
            aria-label="Search images"
            role="combobox"
            aria-expanded={open && items.length > 0}
            aria-controls={listId}
            aria-autocomplete="list"
            autoComplete="off"
            autoCapitalize="off"
            spellCheck={false}
            className={`min-w-0 flex-1 bg-transparent font-semibold text-[#352a17] placeholder-[#7a6d5a] outline-none ${
              isBar ? "text-[15px]" : "text-[16px]"
            }`}
          />
          {value && (
            <button
              type="button"
              aria-label="Clear search"
              onClick={() => {
                setValue("");
                refresh("");
                inputRef.current?.focus();
              }}
              className="ripple-host grid h-8 w-8 shrink-0 place-items-center rounded-full text-[#7d6845]"
            >
              <IconClose className="h-4 w-4" />
            </button>
          )}
          {onFilter && (
            <button
              type="button"
              aria-label={filterCount > 0 ? `Filters (${filterCount} active)` : "Filters"}
              onClick={onFilter}
              className="ripple-host relative ml-0.5 grid h-10 w-10 shrink-0 place-items-center rounded-full text-[#4a3b28]"
            >
              <IconFilter className="h-5 w-5" />
              {filterCount > 0 && (
                <span className="badge-pop pointer-events-none absolute right-0 top-0 grid h-4 min-w-4 place-items-center rounded-full bg-[#b03a26] px-1 text-[10px] font-black text-white">
                  {filterCount}
                </span>
              )}
            </button>
          )}
          {!isBar && (
            <button
              type="submit"
              aria-label="Search"
              className="btn-brass-round ripple-host ml-1 grid h-10 w-10 shrink-0 place-items-center rounded-full"
            >
              <IconSearch className="h-[18px] w-[18px]" />
            </button>
          )}
        </div>
      </form>

      {open && items.length > 0 && (
        <div
          id={listId}
          className="paper drop-in absolute inset-x-0 top-[calc(100%+8px)] z-50 overflow-hidden p-1.5"
          role="listbox"
          aria-label="Recent searches"
        >
          <p className="px-3 pb-1 pt-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-[#7d6845]">
            Recent
          </p>
          {items.map((s, i) => (
            <button
              key={s}
              type="button"
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => submit(s)}
              onMouseEnter={() => setActive(i)}
              role="option"
              aria-selected={i === active}
              className={`flex w-full items-center gap-2.5 rounded-md px-3 py-2 text-left text-[14px] font-semibold transition-transform duration-150 ${
                i === active ? "translate-x-1 bg-[#e2d5b8] text-[#352a17]" : "text-[#54452f]"
              }`}
            >
              <IconHistory className="h-4 w-4 shrink-0 text-[#8a744f]" />
              <span className="truncate">{s}</span>
            </button>
          ))}
          <button
            type="button"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => {
              writeRecents([]);
              setItems([]);
              setOpen(false);
            }}
            className="ripple-host mt-1 w-full rounded-md px-3 py-2 text-left text-[11px] font-bold uppercase tracking-[0.18em] text-[#73351f]"
          >
            Clear history
          </button>
        </div>
      )}
    </div>
  );
}
