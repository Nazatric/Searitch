"use client";

import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
} from "react";
import { showToast } from "@/components/feedback";
import {
  IconBack,
  IconClose,
  IconSearch,
  IconShield,
  IconSparkles,
  IconUp,
} from "@/components/icons";
import Masonry from "@/components/masonry";
import SearchField from "@/components/search-field";
import { Chip, FilterRow, SkeletonCards, Spinner } from "@/components/ui";
import { getJob, retryJob, setSearchContext, useJobs } from "@/lib/client-cache";
import { ghostFly, lockScroll, rectOf, setScrollTop } from "@/lib/flight";
import {
  activeFilterCount,
  COLORS,
  DEFAULT_FILTERS,
  filtersToParams,
  searchKey,
  type Filters,
} from "@/lib/model";
import { mark } from "@/lib/perf";
import { useNavActions, useScroller, type Origin } from "@/lib/nav";

/** Remembered per search so coming back (or re-opening it) lands where you were. */
const pagesMemory = new Map<string, number>();
const scrollByKey = new Map<string, number>();

export default function SearchScreen({
  q,
  filters,
  origin,
  entryId,
  active,
}: {
  q: string;
  filters: Filters;
  origin?: Origin;
  entryId: number;
  active: boolean;
}) {
  mark("search:render");
  const nav = useNavActions();
  const scroller = useScroller();
  const rootRef = useRef<HTMLDivElement>(null);
  const sentinelRef = useRef<HTMLDivElement>(null);

  const baseKey = useMemo(() => filtersToParams(q, filters).toString(), [q, filters]);
  const [pageState, setPageState] = useState<{ key: string; n: number } | null>(null);
  const pages = pageState && pageState.key === baseKey ? pageState.n : (pagesMemory.get(baseKey) ?? 1);
  const keys = useMemo(
    () => Array.from({ length: pages }, (_, i) => searchKey(q, filters, i + 1)),
    [q, filters, pages],
  );
  const { results, done, error, lastCount, lastDone } = useJobs(keys);

  const [sheetOpen, setSheetOpen] = useState(false);
  const [draft, setDraft] = useState<Filters>(filters);
  const [showTop, setShowTop] = useState(false);

  const nActive = activeFilterCount(filters);
  const hasMore = lastDone && lastCount >= 12 && pages < 20;
  const loadingMore = pages > 1 && !lastDone;
  const loading = results.length === 0 && !done && !error;

  useEffect(() => {
    if (active) setSearchContext(q);
  }, [active, q]);

  /* ── glide the Home search field up into this bar (one-shot) ── */
  const [origin0] = useState(origin);
  const [entryId0] = useState(entryId);
  useLayoutEffect(() => {
    if (!origin0 || origin0.kind !== "field") return;
    const bar = rootRef.current?.querySelector<HTMLElement>('[data-field="bar"]');
    if (!bar) return;
    const to = rectOf(bar);
    bar.style.opacity = "0";
    const g = ghostFly({ from: origin0.rect, to, className: "field", radius: 12 });
    nav.consume(entryId0);
    void g.done.then(() => {
      bar.style.opacity = "";
      g.remove();
    });
    return () => {
      g.cancel();
      bar.style.opacity = "";
    };
  }, [origin0, entryId0, nav]);

  /* ── per-search scroll memory ── */
  useLayoutEffect(() => {
    const el = scroller.current;
    if (!el) return;
    setScrollTop(el, scrollByKey.get(baseKey) ?? 0);
    return () => {
      scrollByKey.set(baseKey, el.scrollTop);
    };
  }, [baseKey, scroller]);

  /* ── back-to-top button ── */
  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    const onScroll = () => setShowTop(el.scrollTop > 700);
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, [scroller]);

  /* ── lock the page behind the sheet; Esc closes it ── */
  useEffect(() => {
    const el = scroller.current;
    if (!el || !sheetOpen) return;
    lockScroll(el, true);
    return () => lockScroll(el, false);
  }, [sheetOpen, scroller]);
  useEffect(() => {
    if (!active) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setSheetOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [active]);

  /* ── endless scroll: fetch the next page before the user reaches the end ── */
  const more = useCallback(() => {
    const n = pages + 1;
    pagesMemory.set(baseKey, n);
    setPageState({ key: baseKey, n });
  }, [pages, baseKey]);

  useEffect(() => {
    const el = sentinelRef.current;
    const root = scroller.current;
    if (!el || !root || !active || !hasMore) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) more();
      },
      { root, rootMargin: "900px 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [active, hasMore, more, scroller]);

  const navigate = (q2: string, f2: Filters) => {
    const clean = q2.trim();
    if (!clean) return;
    getJob(searchKey(clean, f2, 1));
    nav.search(clean, f2);
  };

  const applyFilters = () => {
    setSheetOpen(false);
    showToast(activeFilterCount(draft) > 0 ? "Filters applied" : "Filters cleared");
    navigate(q, draft);
  };

  /** Currently applied filters, each with the filter set minus itself. */
  const activeLabels = useMemo(() => {
    const out: Array<{ key: string; label: string; without: Filters }> = [];
    const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
    const orient: Record<string, string> = { wide: "Landscape", tall: "Portrait", square: "Square" };
    if (filters.type !== "any")
      out.push({
        key: "type",
        label: filters.type === "transparent" ? "Transparent" : filters.type.toUpperCase(),
        without: { ...filters, type: "any" },
      });
    if (filters.aspect !== "any")
      out.push({ key: "aspect", label: orient[filters.aspect], without: { ...filters, aspect: "any" } });
    if (filters.size !== "any")
      out.push({ key: "size", label: `${cap(filters.size)} size`, without: { ...filters, size: "any" } });
    if (filters.color)
      out.push({
        key: "color",
        label: COLORS.find((c) => c.key === filters.color)?.label ?? filters.color,
        without: { ...filters, color: "" },
      });
    if (filters.license !== "any")
      out.push({
        key: "license",
        label: filters.license === "commercial" ? "Commercial use" : "Allows editing",
        without: { ...filters, license: "any" },
      });
    if (filters.provider !== "all")
      out.push({ key: "provider", label: cap(filters.provider), without: { ...filters, provider: "all" } });
    if (!filters.safe)
      out.push({ key: "safe", label: "Safe search: OFF", without: { ...filters, safe: true } });
    if (!filters.antiAi)
      out.push({ key: "antiAi", label: "AI Art: Allowed", without: { ...filters, antiAi: true } });
    return out;
  }, [filters]);

  /** Smart facets: drill-down suggestions with real counts from the images returned. */
  const facets = useMemo(() => {
    if (results.length < 6) return [];
    const tally = (values: string[]) => {
      const m = new Map<string, number>();
      for (const v of values) if (v) m.set(v, (m.get(v) ?? 0) + 1);
      return [...m.entries()].sort((a, b) => b[1] - a[1]);
    };
    const out: Array<{ key: string; label: string; count: number; next: Filters }> = [];
    for (const [ext, n] of tally(results.map((r) => r.filetype)).slice(0, 3)) {
      const t = ext.toLowerCase() as Filters["type"];
      if (n < 3 || !["jpg", "png", "gif", "svg"].includes(t) || filters.type === t) continue;
      out.push({ key: `t-${t}`, label: `${t.toUpperCase()} only`, count: n, next: { ...filters, type: t } });
    }
    const siteMap: Record<string, Filters["provider"]> = {
      flickr: "flickr",
      wallhaven: "wallhaven",
      "wikimedia commons": "wikimedia",
      "iNaturalist": "inaturalist",
      "NASA": "nasa",
      "The Met": "met",
      "Europeana": "europeana",
      "V&A Museum": "vam",
    };
    for (const [site, n] of tally(results.map((r) => r.sourceSite)).slice(0, 3)) {
      const p = siteMap[site.toLowerCase()];
      if (!p || n < 3 || filters.provider === p) continue;
      out.push({ key: `p-${p}`, label: site, count: n, next: { ...filters, provider: p } });
    }
    const wide = results.filter((r) => r.width && r.height && r.width / r.height >= 1.2).length;
    const tall = results.filter((r) => r.width && r.height && r.width / r.height <= 1 / 1.2).length;
    if (wide >= 4 && filters.aspect !== "wide")
      out.push({ key: "a-wide", label: "Landscape", count: wide, next: { ...filters, aspect: "wide" } });
    if (tall >= 4 && filters.aspect !== "tall")
      out.push({ key: "a-tall", label: "Portrait", count: tall, next: { ...filters, aspect: "tall" } });
    const big = results.filter((r) => r.width * r.height >= 6_000_000).length;
    if (big >= 4 && filters.size !== "large")
      out.push({ key: "s-large", label: "High-res", count: big, next: { ...filters, size: "large" } });
    return out.slice(0, 6);
  }, [results, filters]);

  const emptyResult = done && results.length === 0;

  return (
    <div ref={rootRef} className="min-h-full pb-28">
      {/* ── leather strap ── */}
      <header className="bar flex min-w-0 items-center gap-2">
        <button
          type="button"
          onClick={() => nav.back()}
          aria-label="Back"
          className="btn-well ripple-host grid h-11 w-11 shrink-0 place-items-center"
        >
          <IconBack className="h-6 w-6" />
        </button>
        <SearchField
          key={q}
          initialValue={q}
          variant="bar"
          onSearch={(q2) => navigate(q2, filters)}
          onPreview={(q2) => getJob(searchKey(q2, filters, 1))}
          filterCount={nActive}
          onFilter={() => {
            setDraft(filters);
            setSheetOpen(true);
          }}
        />
        {!done && <div className="progress" aria-hidden />}
      </header>

      <div className="px-3">
        {/* ── active filters + smart facets (space reserved while loading) ── */}
        {loading ? (
          <div aria-hidden className="-mx-3 mt-3 flex gap-2 overflow-hidden px-3">
            {[96, 84, 108, 90].map((w, i) => (
              <div key={i} className="shimmer h-[30px] shrink-0 rounded-full" style={{ width: w }} />
            ))}
          </div>
        ) : (
          (facets.length > 0 || activeLabels.length > 0) && (
            <div
              key={`facets-${baseKey}`}
              className="fade-up -mx-3 mt-3 flex gap-2 overflow-x-auto px-3 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
            >
              {activeLabels.map((a) => (
                <button
                  key={`on-${a.key}`}
                  type="button"
                  aria-label={`Remove filter ${a.label}`}
                  onClick={() => navigate(q, a.without)}
                  className="chip chip-on ripple-host inline-flex shrink-0 items-center gap-1.5 rounded-full py-1.5 pl-3.5 pr-2.5 text-[12px] font-bold"
                >
                  {a.label}
                  <IconClose className="h-3.5 w-3.5" />
                </button>
              ))}
              {facets.map((fc, i) => (
                <button
                  key={fc.key}
                  type="button"
                  onClick={() => navigate(q, fc.next)}
                  style={{ "--delay": `${i * 40}ms` } as CSSProperties}
                  className="chip chip-paper ripple-host fade-up shrink-0 rounded-full px-3.5 py-1.5 text-[12px] font-bold"
                >
                  {fc.label}
                  <span className="ml-1.5 text-[10px] font-black text-[#8a744f]">{fc.count}</span>
                </button>
              ))}
            </div>
          )
        )}

        <main className="mt-4">
          {loading && <SkeletonCards n={10} />}

          {!loading && results.length === 0 && (error || emptyResult) && (
            <div className="paper fade-up mx-auto mt-6 max-w-md px-5 py-7 text-center">
              <div className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-full bg-[#e2d5b8] text-[#7d6845]">
                <IconSearch className="h-6 w-6" />
              </div>
              <p className="font-display text-lg text-[#73351f]">
                {error ? "Couldn’t search" : "Nothing found"}
              </p>
              <p className="mt-1 text-sm leading-relaxed text-[#5f5138]">
                {error ?? "No images matched. Try a broader keyword or loosen a filter."}
              </p>
              {activeLabels.length > 0 && (
                <div className="mt-4 flex flex-wrap justify-center gap-2">
                  {activeLabels.map((a) => (
                    <button
                      key={`rm-${a.key}`}
                      type="button"
                      onClick={() => navigate(q, a.without)}
                      className="chip chip-paper ripple-host inline-flex items-center gap-1.5 rounded-full py-1.5 pl-3.5 pr-2.5 text-[12px] font-bold"
                    >
                      Remove {a.label}
                      <IconClose className="h-3.5 w-3.5" />
                    </button>
                  ))}
                  {activeLabels.length > 1 && (
                    <button
                      type="button"
                      onClick={() => navigate(q, DEFAULT_FILTERS)}
                      className="chip chip-on ripple-host rounded-full px-3.5 py-1.5 text-[12px] font-bold"
                    >
                      Clear all filters
                    </button>
                  )}
                </div>
              )}
              {(error || activeLabels.length === 0) && (
                <button
                  type="button"
                  onClick={() => keys.forEach((k) => retryJob(k))}
                  className="btn-brass ripple-host mt-4 rounded-lg px-6 py-2.5 text-xs"
                >
                  Try again
                </button>
              )}
            </div>
          )}

          {results.length > 0 && (
            <>
              <p className="label mb-3 px-0.5 text-[11px]">
                {results.length}
                {hasMore || !done ? "+" : ""} results · “{q}”
              </p>
              <Masonry images={results} />
              <div ref={sentinelRef} className="h-px" />
              {loadingMore && (
                <div className="flex justify-center py-6">
                  <Spinner className="h-6 w-6" />
                </div>
              )}
              {done && !hasMore && (
                <p className="label fade-up mt-8 text-center text-[10px] opacity-60">
                  — end of results —
                </p>
              )}
            </>
          )}
        </main>
      </div>

      {/* ── back-to-top ── */}
      {showTop && active && (
        <button
          type="button"
          aria-label="Back to top"
          onClick={() => scroller.current?.scrollTo({ top: 0, behavior: "smooth" })}
          className="btn-brass-round ripple-host fab-in safe-fab grid h-12 w-12 place-items-center rounded-full"
        >
          <IconUp className="h-5 w-5" />
        </button>
      )}

      {/* ── filter sheet ── */}
      {sheetOpen && active && (
        <div
          className="backdrop-in fixed inset-0 z-50 bg-[#150b05]/70"
          onClick={() => setSheetOpen(false)}
        >
          <div
            className="sheet sheet-in absolute inset-x-0 bottom-0 max-h-[88dvh] overflow-y-auto overscroll-contain px-4 pt-10 sm:mx-auto sm:max-w-2xl sm:px-5"
            style={{ paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 24px)" }}
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-label="Search filters"
          >
            <div className="mb-3 flex items-center justify-between px-1">
              <h2 className="label text-[15px]">Filters</h2>
              <button
                type="button"
                onClick={() => setDraft(DEFAULT_FILTERS)}
                className="ripple-host rounded-full px-2 py-1 text-[12px] font-bold uppercase tracking-widest text-[#e8cd96] underline decoration-dotted underline-offset-4"
              >
                Reset all
              </button>
            </div>

            <div className="paper p-4">
              <div className="space-y-5">
                <FilterRow
                  label="File type"
                  value={draft.type}
                  onChange={(v) => setDraft({ ...draft, type: v })}
                  options={[
                    { v: "any", l: "Any" },
                    { v: "jpg", l: "JPG" },
                    { v: "png", l: "PNG" },
                    { v: "gif", l: "GIF" },
                    { v: "svg", l: "SVG" },
                    { v: "transparent", l: "Transparent" },
                  ]}
                />
                <FilterRow
                  label="Orientation"
                  value={draft.aspect}
                  onChange={(v) => setDraft({ ...draft, aspect: v })}
                  options={[
                    { v: "any", l: "Any" },
                    { v: "wide", l: "Landscape" },
                    { v: "tall", l: "Portrait" },
                    { v: "square", l: "Square" },
                  ]}
                />
                <FilterRow
                  label="Size"
                  value={draft.size}
                  onChange={(v) => setDraft({ ...draft, size: v })}
                  options={[
                    { v: "any", l: "Any" },
                    { v: "small", l: "Small" },
                    { v: "medium", l: "Medium" },
                    { v: "large", l: "Large" },
                  ]}
                />
                <div>
                  <p className="font-display mb-2 text-[11px] uppercase tracking-[0.2em] text-[#6d5636]">
                    Color
                  </p>
                  <div className="flex flex-wrap gap-2.5">
                    {COLORS.map((c) => (
                      <button
                        key={c.key}
                        type="button"
                        title={c.label}
                        aria-label={c.label}
                        aria-pressed={draft.color === c.key}
                        onClick={() => setDraft({ ...draft, color: draft.color === c.key ? "" : c.key })}
                        className="chip ripple-host h-9 w-9 rounded-full border-2"
                        style={{
                          backgroundColor: c.css,
                          borderColor: draft.color === c.key ? "#c9a24b" : "rgba(0,0,0,0.25)",
                          boxShadow:
                            draft.color === c.key
                              ? "0 0 0 3px rgba(201,162,75,0.5), inset 0 2px 3px rgba(0,0,0,0.3)"
                              : "inset 0 2px 3px rgba(0,0,0,0.3)",
                        }}
                      />
                    ))}
                  </div>
                </div>
                <FilterRow
                  label="License"
                  value={draft.license}
                  onChange={(v) => setDraft({ ...draft, license: v })}
                  options={[
                    { v: "any", l: "Any" },
                    { v: "commercial", l: "Commercial use" },
                    { v: "modification", l: "Allows editing" },
                  ]}
                />
                <FilterRow
                  label="Source"
                  value={draft.provider}
                  onChange={(v) => setDraft({ ...draft, provider: v })}
                  options={[
                    { v: "all", l: "All sources" },
                    { v: "wikimedia", l: "Wikimedia + museums" },
                    { v: "wallhaven", l: "Wallhaven" },
                    { v: "flickr", l: "Flickr (Safe Search off only)" },
                    { v: "inaturalist", l: "iNaturalist" },
                    { v: "nasa", l: "NASA" },
                    { v: "met", l: "The Met" },
                    { v: "europeana", l: "Europeana" },
                    { v: "vam", l: "V&A Museum" },
                  ]}
                />

                <div className="space-y-1.5 border-t border-[#6d5636]/15 pt-4">
                  <p className="font-display text-[11px] uppercase tracking-[0.2em] text-[#6d5636]">
                    Safe Search
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <Chip
                      on={draft.safe}
                      onClick={() => setDraft({ ...draft, safe: true })}
                    >
                      <span className="inline-flex items-center gap-1.5">
                        <IconShield className="h-3.5 w-3.5" /> Strict (Safe ON)
                      </span>
                    </Chip>
                    <Chip
                      on={!draft.safe}
                      onClick={() => setDraft({ ...draft, safe: false })}
                    >
                      Off (Unrestricted)
                    </Chip>
                  </div>
                  <p className="text-[11px] text-[#7a6d5a]">
                    Hides adult or explicit content identified by the source. Some sources provide limited safety metadata.
                  </p>
                </div>

                <div className="space-y-1.5 border-t border-[#6d5636]/15 pt-4">
                  <p className="font-display text-[11px] uppercase tracking-[0.2em] text-[#6d5636]">
                    Anti-AI Search Filter
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <Chip
                      on={draft.antiAi}
                      onClick={() => setDraft({ ...draft, antiAi: true })}
                    >
                      <span className="inline-flex items-center gap-1.5">
                        <IconSparkles className="h-3.5 w-3.5" /> Block AI Images (ON)
                      </span>
                    </Chip>
                    <Chip
                      on={!draft.antiAi}
                      onClick={() => setDraft({ ...draft, antiAi: false })}
                    >
                      Allow AI Art
                    </Chip>
                  </div>
                  <p className="text-[11px] text-[#7a6d5a]">
                    Hides results whose title, tags or creator identify AI generation. Unlabelled AI images may still appear.
                  </p>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={applyFilters}
              className="btn-brass ripple-host mt-4 w-full rounded-xl py-3.5 text-sm"
            >
              Apply filters
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
