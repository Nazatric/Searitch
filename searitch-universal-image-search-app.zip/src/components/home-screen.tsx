"use client";

import { useEffect, useRef, type CSSProperties } from "react";
import SearchField from "@/components/search-field";
import { getJob } from "@/lib/client-cache";
import { rectOf } from "@/lib/flight";
import { DEFAULT_FILTERS, searchKey } from "@/lib/model";
import { useNavActions } from "@/lib/nav";

/** Minimal landing screen: a stamped wordmark and one search field. */
export default function HomeScreen() {
  const nav = useNavActions();
  const warmTimer = useRef(0);

  useEffect(() => () => window.clearTimeout(warmTimer.current), []);

  // Start the search while the user is still typing → results are usually
  // already arriving by the time they press Enter.
  const preview = (q: string) => {
    window.clearTimeout(warmTimer.current);
    warmTimer.current = window.setTimeout(() => {
      getJob(searchKey(q, DEFAULT_FILTERS, 1));
    }, 220);
  };

  const go = (q: string, field: HTMLElement | null) => {
    window.clearTimeout(warmTimer.current);
    getJob(searchKey(q, DEFAULT_FILTERS, 1));
    nav.search(q, DEFAULT_FILTERS, field ? { kind: "field", rect: rectOf(field) } : undefined);
  };

  return (
    <div className="mx-auto flex min-h-full max-w-xl flex-col items-center justify-center px-6 pb-24 pt-10">
      <div className="fade-up text-center">
        <h1 className="mark pl-[0.12em] text-[40px] leading-none sm:text-[56px]">Searitch</h1>
        <p className="mark-sub mt-3">Search anything</p>
      </div>
      <div className="fade-up mt-11 w-full" style={{ "--delay": "110ms" } as CSSProperties}>
        <SearchField variant="home" onSearch={go} onPreview={preview} autoFocus />
      </div>
    </div>
  );
}
