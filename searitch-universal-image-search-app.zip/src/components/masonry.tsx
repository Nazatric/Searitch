"use client";

import { memo, useMemo } from "react";
import { PhotoCard } from "@/components/ui";
import { cardRatio, type Img } from "@/lib/model";
import { useColumnCount } from "@/lib/use-columns";

/** Cards are photos only (no caption row), so the reserved height is exact. */
const CAPTION = 0.06;

/**
 * Stable masonry. Each card is placed once, into the currently shortest
 * column, using its reserved aspect ratio. Streaming in more results — or
 * loading another page — never moves a card that is already on screen.
 */
function MasonryImpl({ images, maxCols = 4 }: { images: Img[]; maxCols?: number }) {
  const n = useColumnCount(maxCols);

  const columns = useMemo(() => {
    const cols: Array<Array<{ img: Img; index: number }>> = Array.from({ length: n }, () => []);
    const heights = new Array<number>(n).fill(0);
    images.forEach((img, index) => {
      let target = 0;
      for (let c = 1; c < n; c++) {
        if (heights[c] < heights[target] - 0.001) target = c;
      }
      cols[target].push({ img, index });
      heights[target] += 1 / cardRatio(img) + CAPTION;
    });
    return cols;
  }, [images, n]);

  return (
    <div className="flex items-start gap-3">
      {columns.map((col, ci) => (
        <div key={ci} className="flex min-w-0 flex-1 flex-col gap-4">
          {col.map(({ img, index }) => (
            <PhotoCard key={img.id} img={img} index={index} />
          ))}
        </div>
      ))}
    </div>
  );
}

export default memo(MasonryImpl);
