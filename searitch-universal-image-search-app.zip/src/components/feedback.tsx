"use client";

import { useEffect, useRef, useState } from "react";

/* ───────────────────────── global ripple engine ───────────────────────────
   One document-level listener animates every `.ripple-host` in the app.
   Pure transform/opacity keyframes → zero layout work, zero jank.          */

export function RippleListener() {
  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;

    const onDown = (e: PointerEvent) => {
      const target = e.target as HTMLElement | null;
      const host = target?.closest?.(".ripple-host") as HTMLElement | null;
      if (!host) return;
      const rect = host.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height) * 2.2;
      const dot = document.createElement("span");
      dot.className = "ripple-dot";
      dot.style.width = `${size}px`;
      dot.style.height = `${size}px`;
      dot.style.left = `${e.clientX - rect.left - size / 2}px`;
      dot.style.top = `${e.clientY - rect.top - size / 2}px`;
      host.appendChild(dot);
      dot.addEventListener("animationend", () => dot.remove(), { once: true });
    };

    document.addEventListener("pointerdown", onDown, { passive: true });
    return () => document.removeEventListener("pointerdown", onDown);
  }, []);
  return null;
}

/* ────────────────────────────────── toasts ─────────────────────────────── */

type Toast = { id: number; message: string; leaving: boolean };
let toastId = 0;

export function showToast(message: string) {
  window.dispatchEvent(
    new CustomEvent<string>("searitch-toast", { detail: message }),
  );
}

export function ToastHost() {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const timersRef = useRef<number[]>([]);

  useEffect(() => {
    const timers = timersRef.current;
    const onToast = (e: Event) => {
      const message = (e as CustomEvent<string>).detail;
      const id = ++toastId;
      setToasts((prev) => [...prev.slice(-2), { id, message, leaving: false }]);
      timers.push(
        window.setTimeout(() => {
          setToasts((prev) =>
            prev.map((t) => (t.id === id ? { ...t, leaving: true } : t)),
          );
          window.setTimeout(
            () => setToasts((prev) => prev.filter((t) => t.id !== id)),
            260,
          );
        }, 2400),
      );
    };
    window.addEventListener("searitch-toast", onToast);
    return () => {
      window.removeEventListener("searitch-toast", onToast);
      timers.forEach(clearTimeout);
    };
  }, []);

  if (toasts.length === 0) return null;

  return (
    <div
      aria-live="polite"
      className="toast-dock pointer-events-none fixed inset-x-0 z-[70] flex flex-col items-center gap-2 px-4"
    >
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`paper stitched rounded-full px-6 py-2.5 text-[13px] font-bold text-[#443720] shadow-lg ${
            t.leaving ? "toast-out" : "toast"
          }`}
        >
          {t.message}
        </div>
      ))}
    </div>
  );
}
