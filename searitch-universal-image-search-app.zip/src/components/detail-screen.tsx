"use client";

import { useEffect, useLayoutEffect, useRef, useState, type CSSProperties } from "react";
import { showToast } from "@/components/feedback";
import {
  IconBack,
  IconCheck,
  IconDownload,
  IconExternal,
  IconLink,
  IconSearch,
} from "@/components/icons";
import Masonry from "@/components/masonry";
import { Meta, SkeletonCards } from "@/components/ui";
import { peekRelated, warmRelated } from "@/lib/client-cache";
import {
  fly,
  findCard,
  holdCard,
  inView,
  rectOf,
  releaseCard,
  type Flight,
} from "@/lib/flight";
import { displayTitle, trueRatio, type Img } from "@/lib/model";
import { mark } from "@/lib/perf";
import { useNavActions, type Origin } from "@/lib/nav";

/** A sharper-than-thumbnail rendition to show while/instead of the multi-MB original. */
function heroUrl(img: Img): string {
  // Wikimedia serves any standard thumb width; 1280px is razor sharp on a phone
  // and a fraction of the original's size. Only valid below the original width.
  if (img.width >= 1280 && /\/thumb\/.+\/\d+px-/.test(img.thumb)) {
    return img.thumb.replace(/\/(\d+)px-/, "/1280px-");
  }
  // Wallhaven originals are huge (6000×4000 ≈ 100 MB decoded). Show a 1080px
  // WebP from the image optimizer instead — sharp on any phone, ~20× lighter.
  if (img.provider === "wallhaven" && /^https:\/\/w\.wallhaven\.cc\/full\//.test(img.full)) {
    return `/_next/image?url=${encodeURIComponent(img.full)}&w=1080&q=75`;
  }
  return img.full;
}

export default function DetailScreen({
  img,
  origin,
  entryId,
  active,
  leaving,
}: {
  img: Img;
  origin?: Origin;
  entryId: number;
  active: boolean;
  leaving: boolean;
}) {
  mark("detail:render");
  const nav = useNavActions();
  const heroRef = useRef<HTMLDivElement>(null);
  const flightRef = useRef<Flight | null>(null);

  const [origin0] = useState(origin);
  const [entryId0] = useState(entryId);
  const cardOrigin = origin0?.kind === "card" ? origin0 : null;
  const ar = trueRatio(img) ?? (cardOrigin ? cardOrigin.nat.w / cardOrigin.nat.h : 4 / 3);

  const [heroSrc, setHeroSrc] = useState(cardOrigin?.src ?? img.thumb);
  const [measured, setMeasured] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [related, setRelated] = useState<Img[] | null>(() => {
    const hit = peekRelated(img.id);
    return hit ? hit.filter((r) => r.id !== img.id).slice(0, 18) : null;
  });

  /* ── ENTER: the card's photo lifts out of the grid and grows into the hero ── */
  useLayoutEffect(() => {
    if (!cardOrigin) return;
    mark("detail:layout:start");
    const hero = heroRef.current;
    if (!hero) return;
    const big = rectOf(hero);
    mark("detail:layout:afterRect");
    const card = findCard(cardOrigin.id, "1");
    if (card) holdCard(card, "held");
    hero.style.opacity = "0";
    const f = fly({
      src: cardOrigin.src,
      big,
      small: cardOrigin.rect,
      dir: "in",
      smallRadius: cardOrigin.radius,
      bigRadius: 3,
    });
    flightRef.current = f;
    nav.consume(entryId0);
    mark("detail:layout:end");
    void f.done.then(() => {
      hero.style.opacity = "";
      f.remove();
      if (flightRef.current === f) flightRef.current = null;
    });
    return () => {
      f.cancel();
      hero.style.opacity = "";
    };
  }, [cardOrigin, entryId0, nav]);

  /* ── EXIT: the photo shrinks into the exact (possibly tilted) source print ── */
  useLayoutEffect(() => {
    if (!leaving) return;
    flightRef.current?.cancel();
    flightRef.current = null;

    const finishPlainFade = () => {
      // Deep link, or the source card is genuinely off-screen: use the chrome
      // fade and then remove the detail layer.
      const timer = window.setTimeout(() => nav.finishLeaving(entryId0), 260);
      return () => window.clearTimeout(timer);
    };

    const hero = heroRef.current;
    if (!hero) return finishPlainFade();
    hero.style.opacity = "";
    const big = rectOf(hero);
    const card = findCard(img.id, "0");
    if (!card || !inView(big, 0)) return finishPlainFade();
    const small = rectOf(card);
    if (!inView(small, 60)) return finishPlainFade();

    holdCard(card, "busy");
    hero.style.opacity = "0";
    const src = hero.querySelector("img")?.currentSrc || heroSrc;
    const f = fly({ src, big, small, dir: "out", smallRadius: 2, bigRadius: 3 });
    flightRef.current = f;
    let completed = false;
    void f.done.then(() => {
      completed = true;
      releaseCard(card);
      f.remove();
      if (flightRef.current === f) flightRef.current = null;
      // Keep the detail layer alive until the photo is fully clipped into the
      // original print. This avoids the old 240ms chrome fade unmounting it
      // while the spring flight was still travelling.
      nav.finishLeaving(entryId0);
    });
    return () => {
      if (!completed) {
        f.cancel();
        releaseCard(card);
      }
      hero.style.opacity = "";
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [leaving]);

  /* ── swap the thumbnail for the sharp image once it has loaded ── */
  useEffect(() => {
    let dead = false;
    const url = heroUrl(img);
    const probe = new Image();
    probe.decoding = "async";
    probe.src = url;
    // decode() finishes the (expensive) decode OFF the main thread, so swapping
    // the sharp image in can never cost a frame. On failure we keep the thumbnail.
    probe
      .decode()
      .then(() => {
        if (dead) return;
        setHeroSrc(url);
        setMeasured(`${probe.naturalWidth} × ${probe.naturalHeight}`);
      })
      .catch(() => undefined);
    return () => {
      dead = true;
    };
  }, [img]);

  /* ── similar images (usually already warmed on pointer-down) ── */
  useEffect(() => {
    if (related) return;
    let alive = true;
    void warmRelated(img).then((list) => {
      if (alive) setRelated(list.filter((r) => r.id !== img.id).slice(0, 18));
    });
    return () => {
      alive = false;
    };
  }, [img, related]);

  useEffect(() => {
    if (!active) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && nav.back();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [active, nav]);

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      showToast("Link copied");
    } catch {
      showToast("Couldn’t copy — use the address bar");
    }
  };

  const downloadHref = `/api/download?${new URLSearchParams({
    url: img.full,
    name: img.title.slice(0, 60) || "searitch-image",
  })}`;

  return (
    <div className="min-h-full pb-16">
      <header className="bar flex items-center gap-2.5">
        <button
          type="button"
          onClick={() => nav.back()}
          aria-label="Back"
          className="btn-well ripple-host grid h-11 w-11 shrink-0 place-items-center"
        >
          <IconBack className="h-6 w-6" />
        </button>
        <h1 className="min-w-0 flex-1 truncate text-[13px] font-semibold tracking-[0.02em] text-[#eadbbd]">
          {displayTitle(img.title) ?? "Photo"}
        </h1>
        <button
          type="button"
          onClick={copyLink}
          aria-label="Copy link"
          className="btn-well ripple-host grid h-11 w-11 shrink-0 place-items-center"
        >
          <IconLink className="h-5 w-5" />
        </button>
      </header>

      <div className="mx-auto max-w-3xl px-3 pt-4">
        <div className="paper p-2.5">
          {/* Cards are pure photos, so the title is announced here. */}
          <h2 className="title-line fade-up mb-2 line-clamp-2 px-1 text-[15px] leading-snug">
            {displayTitle(img.title) ?? "Untitled photo"}
          </h2>
          <div ref={heroRef} className="hero" style={{ "--ar": ar } as CSSProperties}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={heroSrc}
              alt={img.title}
              referrerPolicy="no-referrer"
              draggable={false}
              decoding="async"
              className="hero-img"
            />
          </div>

          <div className="mt-3.5 grid grid-cols-2 gap-x-4 gap-y-2.5 px-1 sm:grid-cols-3">
            <Meta k="Source" v={img.sourceSite} delay={120} />
            <Meta k="Type" v={img.filetype ? img.filetype.toUpperCase() : "—"} delay={160} />
            <Meta
              k="Dimensions"
              v={
                img.width && img.height
                  ? `${img.width} × ${img.height}`
                  : (measured ?? "—")
              }
              delay={200}
            />
            {img.creator && <Meta k="Creator" v={img.creator} delay={240} />}
            {img.license && <Meta k="License" v={img.license} delay={280} />}
          </div>

          <div
            className="fade-up mt-4 flex gap-2.5 px-0.5 pb-0.5"
            style={{ "--delay": "240ms" } as CSSProperties}
          >
            <a
              href={downloadHref}
              onClick={() => {
                setSaved(true);
                showToast("Download started");
                window.setTimeout(() => setSaved(false), 2200);
              }}
              className="btn-brass ripple-host flex flex-1 items-center justify-center gap-2 rounded-xl px-4 py-3 text-[13px]"
            >
              {saved ? (
                <>
                  <IconCheck className="h-4 w-4" /> Saved
                </>
              ) : (
                <>
                  <IconDownload className="h-4 w-4" /> Download
                </>
              )}
            </a>
            <a
              href={img.sourceUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="field ripple-host flex flex-1 items-center justify-center gap-2 px-4 py-3 text-[13px] font-extrabold uppercase tracking-[0.14em] text-[#54452f]"
            >
              Source <IconExternal className="h-4 w-4" />
            </a>
          </div>
        </div>

        <section className="mt-8">
          <h2 className="label mb-3 flex items-center gap-3 px-0.5 text-[12px]">
            Similar images
            <span className="h-px flex-1 bg-[#e8cd96]/20" />
          </h2>
          {related === null ? (
            <SkeletonCards n={6} maxCols={3} />
          ) : related.length === 0 ? (
            <div className="paper fade-up flex items-center gap-3 px-4 py-3 text-sm text-[#5f5138]">
              <IconSearch className="h-5 w-5 shrink-0 text-[#7d6845]" />
              No similar images found for this one.
            </div>
          ) : (
            <Masonry images={related} maxCols={3} />
          )}
        </section>
      </div>
    </div>
  );
}
