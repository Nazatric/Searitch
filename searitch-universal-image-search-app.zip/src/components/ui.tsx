"use client";

import { memo, useCallback, useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { warmRelated } from "@/lib/client-cache";
import { rectOf } from "@/lib/flight";
import { mark } from "@/lib/perf";
import { cardRatio, displayTitle, imgToParams, type Img } from "@/lib/model";
import { useNavActions, type Origin } from "@/lib/nav";
import { useColumnCount } from "@/lib/use-columns";

export function Chip({
  on,
  children,
  onClick,
}: {
  on: boolean;
  children: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={on}
      className={`chip ripple-host rounded-full px-3.5 py-1.5 text-[13px] font-semibold ${
        on ? "chip-on" : "chip-paper"
      }`}
    >
      {children}
    </button>
  );
}

export function FilterRow<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: Array<{ v: T; l: string }>;
  onChange: (v: T) => void;
}) {
  return (
    <div>
      <p className="font-display mb-2 text-[11px] uppercase tracking-[0.2em] text-[#6d5636]">
        {label}
      </p>
      <div className="flex flex-wrap gap-2">
        {options.map((o) => (
          <Chip key={o.v} on={value === o.v} onClick={() => onChange(o.v)}>
            {o.l}
          </Chip>
        ))}
      </div>
    </div>
  );
}

export function Spinner({ className = "h-8 w-8" }: { className?: string }) {
  return <div className={`stitch-spinner rounded-full ${className}`} />;
}

export function SkeletonCards({ n, maxCols = 4 }: { n: number; maxCols?: number }) {
  const cols = useColumnCount(maxCols);
  const ratios = [1.5, 0.75, 1.1, 0.7, 1.35, 0.9, 1.6, 0.8];
  const columns: number[][] = Array.from({ length: cols }, () => []);
  for (let i = 0; i < n; i++) columns[i % cols].push(i);
  return (
    <div aria-hidden className="flex items-start gap-2.5">
      {columns.map((col, ci) => (
        <div key={ci} className="flex min-w-0 flex-1 flex-col gap-2.5">
          {col.map((i) => (
            <div
              key={i}
              className="print fade-up"
              style={{ "--delay": `${i * 40}ms` } as CSSProperties}
            >
              <div className="print-img">
                <div className="shimmer w-full" style={{ aspectRatio: ratios[i % ratios.length] }} />
              </div>
              <div className="px-0.5 py-2">
                <div className="shimmer h-2.5 w-2/3 rounded-sm" />
              </div>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

function PhotoCardImpl({ img, index }: { img: Img; index: number }) {
  const nav = useNavActions();
  const [src, setSrc] = useState(img.thumb);
  const [loaded, setLoaded] = useState(false);
  const [broken, setBroken] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const hi = img.thumbHi;
  const href = useMemo(() => `/image?${imgToParams(img)}`, [img]);

  // Start the similar-images request the instant the finger lands, so it is
  // usually finished by the time the zoom completes.
  const prewarm = useCallback(() => {
    void warmRelated(img);
  }, [img]);

  mark("card:render");
  const open = (e: React.MouseEvent<HTMLAnchorElement>) => {
    mark("click:start");
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) {
      return; // let the browser open it in a new tab
    }
    e.preventDefault();
    const box = boxRef.current;
    const el = imgRef.current;
    let origin: Origin | undefined;
    if (box && el && loaded && el.naturalWidth > 0) {
      origin = {
        kind: "card",
        id: img.id,
        rect: rectOf(box),
        src: el.currentSrc || el.src,
        nat: { w: el.naturalWidth, h: el.naturalHeight },
        radius: 2,
      };
    }
    mark("click:beforeOpen");
    nav.openImage(img, origin);
    mark("click:afterOpen");
  };

  // Progressive sharpening: the small thumbnail paints instantly; only once the
  // card is near the viewport do we fetch the sharp one and swap it in.
  useEffect(() => {
    const el = boxRef.current;
    if (!hi || !loaded || !el) return;
    let cancelled = false;
    const io = new IntersectionObserver(
      (entries) => {
        if (!entries.some((e) => e.isIntersecting)) return;
        io.disconnect();
        const probe = new Image();
        probe.onload = () => {
          if (!cancelled) setSrc(hi);
        };
        probe.src = hi; // on error we simply keep the small thumbnail
      },
      { rootMargin: "240px" },
    );
    io.observe(el);
    return () => {
      cancelled = true;
      io.disconnect();
    };
  }, [hi, loaded]);

  // A slow host must never leave a card spinning forever: if the thumbnail
  // hasn't painted in 6 s we try the fallback, then drop the card so the grid
  // never looks broken.
  useEffect(() => {
    const t = window.setTimeout(() => {
      if (loaded) return;
      if (img.thumbFallback && src !== img.thumbFallback) setSrc(img.thumbFallback);
      else setBroken(true);
    }, 6000);
    return () => window.clearTimeout(t);
  }, [loaded, img.thumbFallback, src]);

  if (broken) return null;

  // Deterministic tilt from the id, so a card never jumps between renders.
  // Range ≈ −2.4° … +2.4° — like photos slipped into a book.
  let hash = 0;
  for (let i = 0; i < img.id.length; i++) hash = (hash * 33 + img.id.charCodeAt(i)) | 0;
  const tilt = (((hash >>> 0) % 21) - 10) * 0.24;
  const caption = displayTitle(img.title);

  return (
    <a
      href={href}
      onClick={open}
      onPointerDown={prewarm}
      onPointerEnter={prewarm}
      draggable={false}
      className={`print ${index < 24 ? "print-anim" : ""}`}
      style={
        {
          "--delay": `${(index % 10) * 40}ms`,
          "--tilt": `${tilt}deg`,
        } as CSSProperties
      }
    >
      <div ref={boxRef} data-card-id={img.id} className="print-img">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          ref={imgRef}
          src={src}
          alt={img.title}
          loading={index < 6 ? "eager" : "lazy"}
          fetchPriority={index < 4 ? "high" : "auto"}
          decoding="async"
          draggable={false}
          referrerPolicy="no-referrer"
          onLoad={() => setLoaded(true)}
          onError={() => {
            if (img.thumbFallback && src !== img.thumbFallback) setSrc(img.thumbFallback);
            else setBroken(true);
          }}
          className={`thumb block w-full object-cover ${loaded ? "loaded" : ""}`}
          style={{ aspectRatio: cardRatio(img) }}
        />
      </div>
    </a>
  );
}

/** Memoised: re-rendering a covered screen must not re-render its whole grid. */
export const PhotoCard = memo(PhotoCardImpl);

export function Meta({ k, v, delay = 0 }: { k: string; v: string; delay?: number }) {
  return (
    <p className="fade-up min-w-0" style={{ "--delay": `${delay}ms` } as CSSProperties}>
      <span className="block text-[10px] font-bold uppercase tracking-[0.14em] text-[#7d6845]">
        {k}
      </span>
      <span className="block truncate text-[13px] font-semibold text-[#3f3520]" title={v}>
        {v}
      </span>
    </p>
  );
}
