"use client";

import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from "react";
import DetailScreen from "@/components/detail-screen";
import HomeScreen from "@/components/home-screen";
import SearchScreen from "@/components/search-screen";
import { releaseStale } from "@/lib/flight";
import { mark } from "@/lib/perf";
import {
  NavProvider,
  ScrollerCtx,
  scrollMemory,
  useLayers,
  useNavActions,
  type Layer,
} from "@/lib/nav";

/**
 * One screen of the stack: a fixed full-viewport layer with its own scroller,
 * exactly like a native back-stack entry. Scroll position survives the screen
 * being covered (it stays mounted) and even being unmounted far below the top.
 */
function ScreenLayer({ layer, z, children }: { layer: Layer; z: number; children: ReactNode }) {
  const { finishLeaving } = useNavActions();
  const { key, entry, depth, leaving } = layer;
  const [enter] = useState<string>(entry.anim); // frozen at mount: never replay
  const rootRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const y = scrollMemory.get(key);
    if (y) el.scrollTop = y;
    return () => {
      scrollMemory.set(key, el.scrollTop);
    };
  }, [key]);

  // Safety net: a leaving layer is always removed, even if animationend or a
  // shared-photo flight callback is missed. DetailScreen normally removes
  // itself only after its hero has landed back in the source card.
  useEffect(() => {
    if (!leaving) return;
    const delay = entry.screen.kind === "detail" ? 1800 : 900;
    const t = window.setTimeout(() => finishLeaving(key), delay);
    return () => window.clearTimeout(t);
  }, [leaving, key, finishLeaving, entry.screen.kind]);

  // Photos left hidden by a finished zoom-in reappear once this screen is on top again.
  useEffect(() => {
    if (depth === 0 && !leaving && rootRef.current) releaseStale(rootRef.current);
  }, [depth, leaving]);

  return (
    <div
      ref={rootRef}
      className="screen"
      data-kind={entry.screen.kind}
      data-depth={leaving ? "leaving" : String(Math.min(depth, 2))}
      data-anim={enter}
      inert={leaving || depth !== 0}
      style={{ zIndex: 10 + z }}
      onAnimationEnd={(e) => {
        // Detail screens own their exit lifecycle: the return flight calls
        // finishLeaving when it reaches the original card. The short chrome
        // fade must never unmount a photo that is still travelling.
        if (leaving && entry.screen.kind !== "detail" && e.target === e.currentTarget) {
          finishLeaving(key);
        }
      }}
    >
      <div ref={scrollRef} className="screen-scroll">
        <ScrollerCtx.Provider value={scrollRef}>{children}</ScrollerCtx.Provider>
      </div>
    </div>
  );
}

function Screens() {
  mark("screens:render");
  const layers = useLayers();
  // Screens deeper than 3 below the top are unmounted (their scroll is remembered).
  const shown = layers.filter((l) => l.depth <= 3);
  return (
    <>
      {shown.map((layer, i) => {
        const s = layer.entry.screen;
        const active = layer.depth === 0 && !layer.leaving;
        return (
          <ScreenLayer key={layer.key} layer={layer} z={i}>
            {s.kind === "home" ? (
              <HomeScreen />
            ) : s.kind === "search" ? (
              <SearchScreen
                q={s.q}
                filters={s.filters}
                origin={layer.entry.origin}
                entryId={layer.entry.id}
                active={active}
              />
            ) : (
              <DetailScreen
                img={s.img}
                origin={layer.entry.origin}
                entryId={layer.entry.id}
                active={active}
                leaving={layer.leaving}
              />
            )}
          </ScreenLayer>
        );
      })}
    </>
  );
}

export default function AppShell({ initial }: { initial: "home" | "search" | "detail" }) {
  useEffect(() => {
    const vv = window.visualViewport;
    if (!vv) return;
    // How much of the layout viewport is hidden behind the mobile browser bar.
    // Fixed/absolute controls use this so they stay inside the visible area.
    const update = () => {
      const hidden = Math.max(0, window.innerHeight - vv.offsetTop - vv.height);
      document.documentElement.style.setProperty("--vv-bottom", `${Math.round(hidden)}px`);
    };
    update();
    vv.addEventListener("resize", update);
    vv.addEventListener("scroll", update);
    window.addEventListener("orientationchange", update);
    return () => {
      vv.removeEventListener("resize", update);
      vv.removeEventListener("scroll", update);
      window.removeEventListener("orientationchange", update);
    };
  }, []);

  return (
    <NavProvider initial={initial}>
      <Screens />
    </NavProvider>
  );
}
