import {
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

// Logs every real query typed into Searitch. Powers the "trending on
// Searitch" chips on the home page — no fake data, only what users search.
export const searches = pgTable(
  "searches",
  {
    id: serial("id").primaryKey(),
    query: text("query").notNull(),
    count: integer("count").notNull().default(1),
    lastSearchedAt: timestamp("last_searched_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [uniqueIndex("searches_query_unique").on(table.query)],
);
