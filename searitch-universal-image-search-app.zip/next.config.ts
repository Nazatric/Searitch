import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    // Wallhaven only publishes ~300px thumbnails. For portrait/square cards we
    // let Next's optimizer fetch the full image once, resize it to a sharp
    // 640px WebP and cache it on disk — so repeat views are instant.
    remotePatterns: [{ protocol: "https", hostname: "w.wallhaven.cc", pathname: "/full/**" }],
    minimumCacheTTL: 60 * 60 * 24 * 7,
    formats: ["image/webp"],
  },
};

export default nextConfig;
