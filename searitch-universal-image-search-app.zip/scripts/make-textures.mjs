// Builds the Searitch surfaces from the high-res sources in assets-src/.
//   node scripts/make-textures.mjs
//
// Quality rules (this is what makes the texture crisp, not soft):
//  • 1 texture pixel = 1 device pixel at 3× density: the leather tile is
//    TILE_CSS×3 pixels, shown at TILE_CSS css px. Never upscaled.
//  • Seamless via a NARROW overlap cross-fade (variance-preserving, smoothstep
//    weights) — the interior of the tile is untouched source pixels. (My
//    previous whole-image Hann blend ghosted/softened the entire grain.)
//  • Only 85% of the large-scale tonal drift is removed, so it still looks
//    like natural hide instead of flat noise.
//  • WebP q86 + a light unsharp. The result is embedded in the stylesheet as
//    data URIs, so the surfaces exist on the very first painted frame.
import sharp from "sharp";
import fs from "node:fs";

const jobs = [
  // tile px (= css px × 3), overlap, css tile size, quality, flatten sigma
  { name: "leather", src: "assets-src/leather-src.png", crop: 1024, overlap: 160, out: 864, q: 84, flat: 56, sharpen: 0.7 },
  { name: "paper", src: "assets-src/paper-src.png", crop: 1024, overlap: 160, out: 576, q: 86, flat: 40, sharpen: 0.4 },
];

const mean3 = (b) => {
  const m = [0, 0, 0];
  const n = b.length / 3;
  for (let i = 0; i < b.length; i += 3) for (let c = 0; c < 3; c++) m[c] += b[i + c];
  return m.map((v) => v / n);
};
const clamp = (v) => (v < 0 ? 0 : v > 255 ? 255 : v);
const smooth = (t) => t * t * (3 - 2 * t);

async function squareCrop(file, side) {
  const meta = await sharp(file).metadata();
  const s = Math.min(side, meta.width, meta.height);
  return sharp(file)
    .extract({ left: Math.floor((meta.width - s) / 2), top: Math.floor((meta.height - s) / 2), width: s, height: s })
    .removeAlpha()
    .toColourspace("srgb")
    .raw()
    .toBuffer({ resolveWithObject: true });
}

async function flattenLowFreq(buf, size, sigma, amount = 0.85) {
  const blurred = await sharp(buf, { raw: { width: size, height: size, channels: 3 } }).blur(sigma).raw().toBuffer();
  const m = mean3(buf);
  const out = Buffer.alloc(buf.length);
  for (let i = 0; i < buf.length; i++) out[i] = clamp(buf[i] - amount * (blurred[i] - m[i % 3]));
  return out;
}

/** P×P source → T×T seamless tile, T = P − O. Interior pixels are untouched. */
function seamless(src, P, O) {
  const T = P - O;
  const m = mean3(src);
  const H = Buffer.alloc(T * P * 3);
  for (let y = 0; y < P; y++) {
    for (let x = 0; x < T; x++) {
      const o = (y * T + x) * 3;
      const a = (y * P + x) * 3;
      if (x >= O) {
        H[o] = src[a]; H[o + 1] = src[a + 1]; H[o + 2] = src[a + 2];
      } else {
        const wn = smooth(x / O), wf = 1 - wn, norm = Math.hypot(wn, wf);
        const f = (y * P + x + T) * 3;
        for (let c = 0; c < 3; c++) H[o + c] = clamp(m[c] + (wn * (src[a + c] - m[c]) + wf * (src[f + c] - m[c])) / norm);
      }
    }
  }
  const out = Buffer.alloc(T * T * 3);
  for (let y = 0; y < T; y++) {
    for (let x = 0; x < T; x++) {
      const o = (y * T + x) * 3;
      if (y >= O) {
        const a = (y * T + x) * 3;
        out[o] = H[a]; out[o + 1] = H[a + 1]; out[o + 2] = H[a + 2];
      } else {
        const wn = smooth(y / O), wf = 1 - wn, norm = Math.hypot(wn, wf);
        const a = (y * T + x) * 3, f = ((y + T) * T + x) * 3;
        for (let c = 0; c < 3; c++) out[o + c] = clamp(m[c] + (wn * (H[a + c] - m[c]) + wf * (H[f + c] - m[c])) / norm);
      }
    }
  }
  return { buf: out, T };
}

const b64 = {};
for (const j of jobs) {
  const { data, info } = await squareCrop(j.src, j.crop);
  const P = info.width;
  const flat = await flattenLowFreq(data, P, j.flat);
  const { buf, T } = seamless(flat, P, j.overlap);

  let img = sharp(buf, { raw: { width: T, height: T, channels: 3 } });
  if (j.out !== T) img = img.resize(j.out, j.out, { kernel: "lanczos3" });
  img = img.sharpen({ sigma: 0.8, m1: j.sharpen, m2: j.sharpen * 1.6 });
  const webp = await img.webp({ quality: j.q, effort: 6, smartSubsample: false }).toBuffer();
  fs.writeFileSync(`assets-src/${j.name}.webp`, webp);
  console.log(`${j.name}: ${j.out}px q${j.q} → ${(webp.length / 1024).toFixed(0)} KB`);
  b64[j.name] = webp.toString("base64");

  // seam preview: 2×2 tiling, crop 700px around the centre where all 4 seams meet
  const one = await sharp(webp).png().toBuffer();
  const grid = await sharp({ create: { width: j.out * 2, height: j.out * 2, channels: 3, background: "#000" } })
    .composite([[0, 0], [j.out, 0], [0, j.out], [j.out, j.out]].map(([left, top]) => ({ input: one, left, top })))
    .png().toBuffer();
  const c = Math.min(700, j.out * 2 - 2);
  await sharp(grid)
    .extract({ left: j.out - c / 2, top: j.out - c / 2, width: c, height: c })
    .jpeg({ quality: 90 })
    .toFile(`.shots/seam-${j.name}.jpg`);
}

let font = "";
if (fs.existsSync("assets-src/cinzel-700.woff2")) {
  const b64 = fs.readFileSync("assets-src/cinzel-700.woff2").toString("base64");
  font = `@font-face {\n  font-family: "Cinzel";\n  font-weight: 700;\n  font-style: normal;\n  font-display: block;\n  src: url("data:font/woff2;base64,${b64}") format("woff2");\n}\n`;
  console.log(`font: Cinzel 700 → ${(b64.length * 0.75 / 1024).toFixed(0)} KB`);
}

// IMPORTANT: never put these data URIs in CSS custom properties. A ~400 KB value
// in a `var()` is re-substituted on every style recalculation of every element
// that uses it — measured at 60–80 ms per class toggle. As plain url() values in
// a single shared rule they are parsed once and cost nothing afterwards.
fs.writeFileSync(
  "src/app/textures.css",
  `/* AUTO-GENERATED by scripts/make-textures.mjs — do not edit by hand.
   Surfaces + wordmark font are embedded so the first painted frame has them.
   Each data URI appears exactly once, and never inside a custom property. */
${font}
/* leather: page, screens, straps, sheets — 864px tile shown at 288 css px (1 texture px = 1 device px at 3x) */
body,
.screen,
.bar,
.sheet {
  background-image: url("data:image/webp;base64,${b64.leather}");
  background-size: 288px 288px;
}

/* paper: cards, prints, fields, chips */
.paper,
.print,
.field,
.chip-paper {
  background-image: url("data:image/webp;base64,${b64.paper}");
  background-size: 288px 288px;
}
`,
);
console.log("wrote src/app/textures.css");
